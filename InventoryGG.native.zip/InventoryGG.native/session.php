<?php 
	session_start();
	$username = "";
	if($_SESSION['status']=="admin" or $_SESSION['status']=="anggota"){
		$username = $_SESSION['username'];
	}else{
		header("location:login.php?pesan=belum_login");
	}
	?>