<?php
    include "connection.php";

    $id_detail_masuk=$_GET["id_detail_masuk"];
    $id_masuk=$_GET["id_masuk"];
    $user=$_GET["user"];
    $status=$_GET["status"];
    
    if($id_detail_masuk != null){
        $query="DELETE FROM detail_peminjaman_masuk where id_detail_masuk = $id_detail_masuk;";
        $delete=mysqli_query($conn,$query);
        if($user = 'admin'){
            echo "<script>alert('Data Berhasil Dihapus')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_masuk&status=$status')</script>";
        }else{
            echo "<script>alert('Data Berhasil Dihapus')
            location.replace('dash_item_peminjaman.php?id_masuk=$id_masuk')</script>";
        }
        
    }else{
        if($user = 'admin'){
            echo "<script>alert('Data Gagal Dihapus')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_masuk&status=$status')</script>";
        }else{
            echo "<script>alert('Data Gagal Dihapus')
            location.replace('dash_item_peminjaman.php?id_masuk=$id_masuk')</script>";
        }
    }

?>