<?php 
	include "connection.php";

    $id_alat = $merk = $id_kat = $type = $tgl_masuk = $tgl_keluar =  $edit = $id_user = "";
    $dateNow= date("Y-m-d");
    $tgl_masuk = $dateNow;
    
    if(isset($_GET['id_alat'])){
        $id_alat    =   $_GET['id_alat'];
        $result=mysqli_query($conn, "SELECT * FROM alat WHERE id_alat = '$id_alat' ");
        while ($row1=mysqli_fetch_array($result)){
            $merk = $row1["merk"];
            $type = $row1["type"];
            $id_kat = $row1["id_kat"];
            $tgl_masuk= $row1["tgl_masuk"];
            $tgl_keluar= $row1["tgl_keluar"];
            $username = $row1["username"];
        }
    }

    if(isset($_GET['merk']) and isset($_GET['id_kat']) and isset($_GET['type'])){
        $merk = $_GET['merk'];
        $type = $_GET['type'];
        $id_kat = $_GET['id_kat'];
        $tgl_masuk= $_GET["tgl_masuk"];
        $tgl_keluar= $_GET["tgl_keluar"];
        $id_user= $_GET["id_user"];
    }

    if(isset($_POST["reset"])){
        $id_alat = $_POST["id_alat"];
        $merk=$_POST["merk"];
        $type=$_POST["type"];
        $id_kat = $_POST["id_kat"];
        $tgl_masuk= $_POST["tgl_masuk"];
        $tgl_keluar= $_POST["tgl_keluar"];
        $id_user= $_POST["id_user"];
        if($id_alat != null){
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('biodata_form.php');
                } else {
                    location.replace('biodata_form.php?edit=true&id_alat=$id_alat');
                }
            </script>";
        }else{
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('biodata_form.php');
                } else {
                    location.replace('biodata_form.php?merk=$merk&id_kat=$id_kat&type=$type');
                }
            </script>";
        }
        
    }

    if(isset($_POST["submit"])){
        $id_alat=$_POST["id_alat"];
        $merk=$_POST["merk"];
        $type=$_POST["type"];
        $id_kat = $_POST["id_kat"];
        $tgl_masuk = $_POST["tgl_masuk"];
        $tgl_keluar= $_POST["tgl_keluar"];
        $username= $_POST["username"];
        $edit=$_POST['edit'];
        $id_userId = "";

        $jumlah = count($_FILES['gambar']['name']);
            $file_name ="";
            if ($jumlah > 0) {
                for ($i=0; $i < $jumlah; $i++) { 
                    $file_name = $_FILES['gambar']['name'][$i];
                    $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                    move_uploaded_file($tmp_name, "images/".$file_name);				
                }
            }
        if($id_alat =="" || $id_alat == null || empty($id_alat)){
            if(($merk and $id_kat and $type) != null){
                if($id_alat == ""){
                    $query =mysqli_query($conn, "SELECT MAX(SUBSTRING(id_alat, -3)) AS maxKode FROM alat;");
                    $data = mysqli_fetch_array($query);
                    $noOrder = $data['maxKode'];
                    $noUrut = (int) $noOrder;
                    $noUrut++;
                    $char = "/INV-ALT/OPA-GG/";
                    $id_alat = $id_kat .$char . sprintf("%03s", $noUrut);
                }
                $query="INSERT INTO alat set id_alat = '$id_alat',merk = '$merk',id_kat = '$id_kat', type = '$type', tgl_masuk = '$tgl_masuk', tgl_keluar ='$tgl_keluar', username = '$username', foto_alat = '$file_name';";
                $sql_insert1 = mysqli_query($conn,$query);
                echo "<script>alert('Data Berhasil Ditambahkan')
                    location.replace('form_checklist.php?id_alat=$id_alat')</script>";
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }else{
            $query="UPDATE alat set merk = '$merk',id_kat = '$id_kat', type = '$type', tgl_masuk = '$tgl_masuk', tgl_keluar ='$tgl_keluar', username = '$username', foto_alat = '$file_name'; where id_alat = $id_alat;";
            $sql_insert1 = mysqli_query($conn,$query);
            echo "<script>alert('Data Berhasil Diubah')
                location.replace('alat.php')</script>";
        }
    }

        include 'header_admin.php';
        $username = $_SESSION['username'];
    ?>

<body>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Alat</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Dashboard</a></li>
                                <li><a href="#">Forms</a></li>
                                <li class="active">Form Alat</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Isikan Data Alat </strong>
                        </div>
                        <div class="card-body card-block">
                            <form action="form_alat.php" method="post" merk="frm" enctype="multipart/form-data"class="form-horizontal">
                                <div class="container">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Nomor Inventaris</label></div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="id_alat" placeholder="ID Alat" class="form-control" value="<?php echo $id_alat; ?>"
                                            <?php if($id_alat != ""){echo "";}else{echo "disabled value = ''";}?>>
                                            <small class="form-text text-muted">Masukkan Merk Alat</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Merk Alat</label></div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="merk" placeholder="Merk Alat" class="form-control" value="<?php echo $merk; ?>">
                                            <small class="form-text text-muted">Masukkan Merk Alat</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="type-input" class=" form-control-label">Tipe Alat</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="type" placeholder="type" class="form-control" value="<?php echo $type; ?>">
                                            <small class="form-text text-muted">Masukkan Tipe Alat</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Jenis Alat</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <select name="id_kat" class="form-control">
                                                <?php
                                                    $query="SELECT * FROM kategori";
                                                    $sql=mysqli_query($conn,$query);
                                                    while ($row=mysqli_fetch_array($sql)) {
                                                        $select = "";
                                                        if ($row['id_kat']==$id_kat) {
                                                            $select="selected";
                                                        }
                                                ?>
                                                <option <?php echo $select; ?> value="<?php echo $row['id_kat'];?>">
                                                    <?php echo $row['name_kat']; ?></option>
                                                <?php
                                                    }
                                                ?>
                                            </select>
                                            <small class="form-text text-muted">pilih jenis alat</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Tanggal Masuk</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="date" id="text-input" name="tgl_masuk" placeholder="Tanggal Masuk" class="form-control" value="<?php echo $tgl_masuk; ?>">
                                            <small
                                                class="help-block form-text">Masukkan Tanggal Masuk</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Tanggal Keluar</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="date" id="text-input" name="tgl_keluar" placeholder="Tanggal Keluar" class="form-control" value="<?php echo $tgl_keluar; ?>"
                                                <?php if($tgl_keluar != ""){echo "";}else{echo "disabled value = ''";}?>>
                                                <small class="help-block form-text">Masukkan Tanggal Keluar</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Petugas</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="username" placeholder="Username" class="form-control" value="<?php echo $username; ?>" disabled value=''>
                                            <small class="help-block form-text">Username akan terisi tomatis</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Lampirkan Foto Alat</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="file" id="text-input" name="gambar[]"placeholder="Choose file" class="form-control" value="">
                                            <?php
                                                if(isset($id_alat)){
                                                    $result1=mysqli_query($conn,"SELECT * FROM alat WHERE id_alat = '$id_alat';");
                                                    while ($row2=mysqli_fetch_array($result1)){
                                            ?>
                                            <small class="help-block form-text"><?php echo $row2["foto_alat"];?></small>
                                            <?php
                                                    }
                                                }
                                            ?>
                                            <small class="help-block form-text">Lampirkan Foto Alat untuk mempermudah proses pengecekan</small>
                                        </div>
                                    </div>
                                    <!-- hidden -->
                                    <input type="text" id="text-input" name="edit" class="form-control" value="<?php echo $edit; ?>" hidden>
                                </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                <i class="fa fa-dot-circle-o"></i> Submit
                            </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

            <?php 
                if(isset($id_alat)){
                    $foto_jaminan = "";
                    $result=mysqli_query($conn,"SELECT foto_alat FROM alat WHERE  id_alat = '$id_alat';");
                    while ($row1=mysqli_fetch_array($result)){
                        $foto_jaminan      =   $row1["foto_alat"];
                    }
                    $hidden_foto = "hidden";
                    if($foto_jaminan != "" || $foto_jaminan != null || !empty($foto_jaminan)){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Alat</strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active">
                                                        <img src="images/<?php echo $foto_jaminan;?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $foto_jaminan;?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>
