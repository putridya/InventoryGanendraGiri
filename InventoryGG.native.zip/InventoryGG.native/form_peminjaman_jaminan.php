<?php 
	include "connection.php";

    $id_peminjaman_masuk = $foto_jaminan = $foto_jaminan = "";

    if(isset($_GET['id_peminjaman_masuk'])){
        $id_peminjaman_masuk    =   $_GET['id_peminjaman_masuk'];
        $result=mysqli_query($conn,"SELECT * FROM peminjaman_masuk WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
        while ($row1=mysqli_fetch_array($result)){
            $nama_peminjam      =   $row1["nama_peminjam"];
            $foto_jaminan     =   $row1["foto_jaminan"];
        }
    }

    if(isset($_POST["submit"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $nama_peminjam          =   $_POST["nama_peminjam"];
        $sql_insert1;

        if($id_peminjaman_masuk != "" || $id_peminjaman_masuk != null || !empty($id_peminjaman_masuk)){
            $jumlah = count($_FILES['gambar']['name']);
            if ($jumlah > 0) {
                for ($i=0; $i < $jumlah; $i++) { 
                    $file_name = $_FILES['gambar']['name'][$i];
                    $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                    move_uploaded_file($tmp_name, "images/".$file_name);			
                }
            }
            $query="UPDATE peminjaman_masuk set nama_peminjam = '$nama_peminjam', foto_jaminan = '$file_name', status = 'diambil' where id_peminjaman_masuk = '$id_peminjaman_masuk';";
            $sql_insert1 = mysqli_query($conn,$query);
            if($sql_insert1){
                echo "<script>alert('Data Jaminan Berhasil Ditambahkan')
                location.replace('form_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }else{
                echo "<script>alert('Data Jaminan Gagal Ditambahkan')
                location.replace('form_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }else{
            echo "<script>alert('Id Peminjaman tidak Ditemukan')
            location.replace('form_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }

        
    }
    
    // HEADER INCLUDE
    include 'header_admin.php';
 ?>

<body>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Peminjaman</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Data Peminjaman</a></li>
                                <li><a href="form_peminjaman.php?edit=true&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>">Form
                                        Peminjaman</a></li>
                                <li class="active">Form Jaminan Alat</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Isikan Data Peminjaman <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <form action="form_peminjaman_jaminan.php" method="post" name="frm" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="container">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Nama Peminjam</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="nama_peminjam" placeholder="Nama Instansi" 
                                                class="form-control" value="<?php echo $nama_peminjam; ?>">
                                            <small class="form-text text-muted">Masukkan Nama Peminjam</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Lampirkan Foto Jaminan</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="file" id="text-input" name="gambar[]" placeholder="Choose file" 
                                                class="form-control" value="" multiple>
                                            <?php
                                                if(isset($_GET['id_peminjaman_masuk'])){
                                                    $result1=mysqli_query($conn,"SELECT * FROM peminjaman_masuk WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
                                                    while ($row2=mysqli_fetch_array($result1)){
                                            ?>
                                                <div class="btn btn-outline-primary btn-sm">
                                                    <?php echo $row2["foto_jaminan"];?>
                                                </div>
                                            <?php
                                                    }
                                                }
                                            ?>
                                            <small class="help-block form-text">Lampirkan Foto Jaminan untuk mempermudah proses peminjaman</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <!-- HIDDEN INPUT -->
                                <input type="text" id="email-input" name="id_peminjaman_masuk" class="form-control"
                                            value="<?php echo $id_peminjaman_masuk; ?>" hidden="hidden">
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                    <i class="fa fa-dot-circle-o"></i> Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


            <?php 
                if(isset($_GET['id_peminjaman_masuk'])){
                    $foto_jaminan = "";
                    $result=mysqli_query($conn,"SELECT foto_jaminan FROM peminjaman_masuk WHERE  id_peminjaman_masuk = '$id_peminjaman_masuk';");
                    while ($row1=mysqli_fetch_array($result)){
                        $foto_jaminan      =   $row1["foto_jaminan"];
                    }
                    $hidden_foto = "hidden";
                    if($foto_jaminan != "" || $foto_jaminan != null || !empty($foto_jaminan)){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Jaminan Peminjam <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active">
                                                        <img src="images/<?php echo $foto_jaminan;?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $foto_jaminan;?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>


            <!-- BUTTON BACK -->
            <div class="float-left">
                <a href="dashboard_admin.php?action=baru.php" class="btn btn-secondary btn-md active float-left" 
                    role="button" aria-pressed="true">
                    < Back
                </a> 
            </div> 

            <!-- BUTTON NEXT -->
            <?php if(isset($_GET['id_peminjaman_masuk'])){ ?>
            <div class="float-right">
                <a href="tampil_peminjaman.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>"
                    class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">
                    Next >
                </a>
            </div>
            <?php } ?>

        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>