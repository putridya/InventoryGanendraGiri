<?php
    include "connection.php";

    $id_peminjaman_masuk=$_GET["id_peminjaman_masuk"];
    $id_alat=$_GET["id_alat"];
    $id_check=$_GET["id_check"];
    $id_detail_masuk=$_GET["id_detail_masuk"];
    $status_peminjaman=$_GET["status_peminjaman"];

    
    if($id_peminjaman_masuk != null){
        if($status_peminjaman == "diambil"){
            $query="INSERT INTO detail_peminjaman_diterima set id_detail_masuk = '$id_detail_masuk', id_alat = '$id_alat', id_check_keluar = '$id_check', 
                        id_check_masuk = '';";
                    $sql_insert1 = mysqli_query($conn,$query);
            echo "<script>alert('Data Peminjaman Alat Berhasil Ditambahkan')
                location.replace('form_peminjaman_list_alat.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }else if($status_peminjaman == "dikembalikan"){
            $id_detail = "";
            $resultChecklist=mysqli_query($conn,"SELECT d.`id_detail` FROM detail_peminjaman_diterima D, `detail_peminjaman_masuk` M WHERE m.`id_detail_masuk` = d.`id_detail_masuk` AND m.`id_peminjaman_masuk` = '$id_peminjaman_masuk' AND d.`id_alat` = '$id_alat'; ") ;
            while ($row6=mysqli_fetch_array($resultChecklist)){
                $id_detail = $row6["id_detail"];
            }
            if($id_detail != "" and !empty($id_detail)){
                $query="UPDATE detail_peminjaman_diterima set id_check_masuk = '$id_check' WHERE id_detail = $id_detail;";
                $sql_insert1 = mysqli_query($conn,$query);
                echo "<script>alert('Data Peminjaman Alat Berhasil Ditambahkan')
                    location.replace('form_peminjaman_list_alat.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }else{
            echo "<script>alert('Status Peminjaman Tidak Ditemukan')
                    location.replace('form_peminjaman_list_alat.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }
        
    }else{
        echo "<script>alert('Id Peminjaman tidak Ditemukan')
        location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
    }
?>