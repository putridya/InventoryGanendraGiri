<?php 
	include "connection.php";

    $id_alat = $merk = $id_kat = $type = $tgl_masuk = $tgl_keluar =  $delete = $id_user = "";
    
    if(isset($_GET['delete']) and isset($_GET['id_alat'])){
        $delete     =   $_GET['delete'];
        $id_alat    =   $_GET['id_alat'];
        $result=mysqli_query($conn, "SELECT * FROM alat WHERE id_alat = $id_alat ");
        while ($row1=mysqli_fetch_array($result)){
            $merk       =   $row1["merk"];
            $type       =   $row1["type"];
            $id_kat     =   $row1["id_kat"];
            $tgl_masuk  =   $row1["tgl_masuk"];
            $tgl_keluar =   $row1["tgl_keluar"];
            $id_user    =   $row1["id_user"];
        }
    }

    if(isset($_GET['merk']) and isset($_GET['id_kat']) and isset($_GET['type'])){
        $merk       =   $_GET['merk'];
        $type       =   $_GET['type'];
        $id_kat     =   $_GET['id_kat'];
        $tgl_masuk  =   $_GET["tgl_masuk"];
        $tgl_keluar =   $_GET["tgl_keluar"];
        $id_user    =   $_GET["id_user"];
    }

    if(isset($_POST["reset"])){
        $id_alat    =   $_POST["id_alat"];
        $merk       =   $_POST["merk"];
        $type       =   $_POST["type"];
        $id_kat     =   $_POST["id_kat"];
        $tgl_masuk  =   $_POST["tgl_masuk"];
        $tgl_keluar =   $_POST["tgl_keluar"];
        $id_user    =   $_POST["id_user"];
        if($id_alat != null){
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('biodata_form.php');
                } else {
                    location.replace('biodata_form.php?delete=true&id_alat=$id_alat');
                }
            </script>";
        }else{
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('biodata_form.php');
                } else {
                    location.replace('biodata_form.php?merk=$merk&id_kat=$id_kat&type=$type');
                }
            </script>";
        }
        
    }

    if(isset($_POST["submit"])){
        $id_alat    =   $_POST["id_alat"];
        $merk       =   $_POST["merk"];
        $type       =   $_POST["type"];
        $id_kat     =   $_POST["id_kat"];
        $tgl_masuk  =   $_POST["tgl_masuk"];
        $tgl_keluar =   $_POST["tgl_keluar"];
        $id_user    =   $_POST["id_user"];
        $delete     =   $_POST['delete'];

        if($delete != true){
            if(($id_alat and $merk and $id_kat and $type) != null){
                $query="UPDATE alat set tgl_keluar = '$tgl_keluar' where id_alat = $id_alat;";
                $sql_insert1 = mysqli_query($conn,$query);
                echo "<script>alert('Data Berhasil Diubah')
                location.replace('tampil_barangKeluar.php?id_alat=$id_alat')</script>";
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }else{
            $query="UPDATE alat set id_alat = '$id_alat',merk = '$merk',id_kat = '$id_kat', type = '$type', tgl_masuk = '$tgl_masuk', tgl_keluar = '$tgl_keluar', id_user = '$id_user' where id_alat = $id_alat;";
            $sql_insert1 = mysqli_query($conn,$query);
            echo "<script>alert('Data Berhasil Diubah')
                location.replace('tabel_alat.php')</script>";
        }
        
    }

    if(isset($_POST["reset"])){
        $merk = $type = $id_kat = null;
    }

    

?>
<SCRIPT LANGUAGE="JavaScript">
    if($id_vendor=null){
        document.frm.id1.hidden = "hidden";
        document.frm.id2.hidden = "hidden";
    }else{
        document.frm.id1.hidden = "";
        document.frm.id1.hidden = "";
    }
<!-- 	
function controlCK(str) {	
	document.frm.submit.disabled = !str;
}
//  End -->
</script>
<?php
        include 'header_admin.php';
    ?>
<body>

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Form Barang Keluar</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="dashboard_admin.php">Dashboard</a></li>
                                    <li><a href="#">Forms</a></li>
                                    <li class="active">Form Alat</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Isikan Data Alat</strong>
                                </div>
                                <div class="card-body card-block">
                                <form action="form_delete_alat.php" method="post" merk="frm" enctype="multipart/form-data" class="form-horizontal">
                                        
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">ID Alat</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="id_alat" placeholder="Id Alat" class="form-control" value="<?php echo $id_alat; ?>" readonly><small class="form-text text-muted">Masukkan ID Alat</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Merk Alat</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="merk" placeholder="Merk Alat" class="form-control" value="<?php echo $merk; ?>" readonly><small class="form-text text-muted">Masukkan Merk Alat</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="type-input" class=" form-control-label">Tipe Alat</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="type" placeholder="type" class="form-control" value="<?php echo $type; ?>" readonly><small class="form-text text-muted">Masukkan Tipe Alat</small></div>
                                        </div>
                                        <div class="row form-group">
                                        <div class="col col-md-3"><label for="text-input" class=" form-control-label" >Jenis Alat</label></div>
                                        <div class="col-12 col-md-9"><select name="id_kat" class="form-control" disabled>
                                            <?php
                                                $query="SELECT * FROM kategori";
                                                $sql=mysqli_query($conn,$query);
                                                while ($row=mysqli_fetch_array($sql)) {
                                                    $select = "";
                                                    if ($row['id_kat']==$id_kat) {
                                                        $select="selected";
                                                    }
                                            ?>
                                            <option <?php echo $select; ?> value="<?php echo $row['id_kat'];?>"><?php echo $row['name_kat']; ?></option>
                                            <?php
                                                }
                                            ?>
                                            </select><small class="form-text text-muted">pilih jenis alat</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tanggal Masuk</label></div>
                                            <div class="col-12 col-md-9"><input type="date" id="text-input" name="tgl_masuk" placeholder="Tanggal Masuk" class="form-control" value="<?php echo $tgl_masuk; ?>" readonly><small class="help-block form-text">Masukkan Tanggal Masuk</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tanggal Keluar</label></div>
                                            <div class="col-12 col-md-9"><input type="date" id="text-input" name="tgl_keluar" placeholder="Tanggal Keluar" class="form-control" value="<?php echo $tgl_keluar; ?>"><small class="help-block form-text">Masukkan Tanggal Keluar</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">id User</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="id_user" placeholder="Id User" class="form-control" value="<?php echo $id_user; ?>" readonly><small class="help-block form-text">Masukkan Id User</small></div>
                                        </div>
                                            
                                    </div>
                                    <div class="card-footer">
                                        <button onclick="window.location.href='tampil_barangKeluar.php'" type="submit" class="btn btn-primary btn-sm" name="submit">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm" merk="reset">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    <div class="clearfix"></div>
        <?php
            include 'footer_admin.php'
        ?>
</body>
</html>
