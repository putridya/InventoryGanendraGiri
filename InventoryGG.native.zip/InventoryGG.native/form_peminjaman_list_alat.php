<?php 
    include "connection.php";
    $id_peminjaman_masuk = $cari_alat = "";
    $search_form = "";

    if(isset($_POST["submit2"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $cari_alat  = $_POST["cari_alat"];
    }

    if(isset($_GET['id_peminjaman_masuk'])){
        $id_peminjaman_masuk    =   $_GET['id_peminjaman_masuk'];
    }

    if(isset($_GET["id_peminjaman_masuk"]) and isset($_GET["id_kat"]) and isset($_GET["jumlah"]) and isset($_GET["id_detail_masuk"])){
        $id_detail_masuk        =   $_GET['id_detail_masuk'];
        $id_peminjaman_masuk    =   $_GET["id_peminjaman_masuk"];
        $id_kat                 =   $_GET["id_kat"];
        $jumlah                 =   $_GET["jumlah"];
    }

    if(isset($_POST["reset2"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $id_detail_masuk        =   $_POST['id_detail_masuk'];
        $id_kat                 =   $_POST["id_kat"];
        $jumlah                 =   $_POST["jumlah"];
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk');
                } else {
                    location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk');
                }
            </script>";
        
    }
    if($id_peminjaman_masuk == ""){
        header('Location: dashboard_admin.php');
    }       

    include 'header_admin.php';
?>
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Pengambilan Alat</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Data Peminjaman</a></li>
                                <li><a href="form_peminjaman.php?edit=true&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>">Form
                                        Peminjaman</a></li>
                                <li class="active">Form Pengambilan Alat</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Permintaan Peminjaman Baru <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row">
                                    <div class="col"> 
                                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Foto Alat</th>
                                                    <th>Jenis Alat</th>
                                                    <th>Permintaan</th>
                                                    <th>Disetujui</th>
                                                    <th>Dikeluarkan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $query="SELECT D.*, K.name_kat, K.foto_kat  FROM detail_peminjaman_masuk D,kategori K WHERE K.id_kat = D.id_kat AND id_peminjaman_masuk = '$id_peminjaman_masuk' ORDER BY D.`id_detail_masuk`";
                                                    $result=mysqli_query($conn,$query) ;
                                                    $i = 0;
                                                    while ($row2=mysqli_fetch_array($result)){
                                                        $i++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td>
                                                        <?php if($row2["foto_kat"] != "" || !empty($row2["foto_kat"] || $row2["foto_kat"] != null)){ ?>
                                                            <div class="text-center">
                                                                <img src="images/<?php echo $row2["foto_kat"];?>" width="120px" height="120px" 
                                                                    class="img-responsive rounded" alt="">
                                                            </div>
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $row2["name_kat"]; ?></td>
                                                    <td><?php echo $row2["jumlah"]; ?></td>
                                                    <td><?php echo $row2["jumlah_dikeluarkan"]; ?></td>
                                                    <td>
                                                        <?php

                                                            $id_detail_masuk = $row2["id_detail_masuk"];
                                                            $jum_kel="";
                                                            $queryKel="SELECT COUNT(*) AS jum_keluar FROM detail_peminjaman_diterima WHERE id_detail_masuk = '$id_detail_masuk'; ";
                                                            $resultKel=mysqli_query($conn,$queryKel) ;
                                                            while ($row6=mysqli_fetch_array($resultKel)){
                                                                $jum_kel = $row6["jum_keluar"];
                                                            }
                                                            echo $jum_kel;
                                                            if($row2["jumlah_dikeluarkan"] <= $jum_kel){
                                                                $search_form .= ", 0";
                                                            }else{
                                                                $search_form .= ", 1";
                                                            }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                        }
                                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                $search_arr = explode(",", $search_form);
                $hidden_search = "";
                for($i = 0; $i < count($search_arr); $i++){
                    if($search_arr[$i] == "0"){
                        $hidden_search = "hidden";
                        break;
                    }
                }
            ?>
            <div class="row" <?php echo $hidden_search; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Cari Alat Alat yang akan dipinjam <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <form action="form_peminjaman_list_alat.php" method="post" name="form" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="container">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Cari Alat </label>
                                        </div>
                                        <div class="col-12 col-md-9"><input type="text" id="email-input" name="cari_alat"
                                                placeholder="Masukkan jumlah alat" class="form-control" value="<?php echo $cari_alat; ?>">
                                                <small class="help-block form-text">Masukkan Id Alat, Nama Alat, Kategori Alat untuk di Tampilkan</small>
                                        </div>
                                        <input type="text" id="email-input" name="id_peminjaman_masuk" hidden="hidden"
                                            class="form-control" value="<?php echo $id_peminjaman_masuk; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit2">
                                    <i class="fa fa-dot-circle-o"></i> Search
                                </button>
                                <button type="submit" class="btn btn-danger btn-sm" name="reset2">
                                    <i class="fa fa-ban"></i> Reset
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            

            <?php 
                if(!empty($cari_alat)){
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Hasil Pencarian Alat</strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row">
                                    <div class="col"> 
                                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>No. Inventaris</th>
                                                    <th>Foto Alat</th>
                                                    <th>Nama Alat</th>
                                                    <th>Kategori</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $query="SELECT a.*, k.`name_kat`, m.`id_detail_masuk` FROM alat A, kategori K, detail_peminjaman_masuk M WHERE A.`id_kat` = k.`id_kat` AND m.`id_kat` = a.`id_kat` AND m.`id_peminjaman_masuk` = '$id_peminjaman_masuk' AND(a.`id_alat` LIKE '%$cari_alat%' OR a.`merk` LIKE '%$cari_alat%' OR a.`type` LIKE '%$cari_alat%' OR k.`name_kat` LIKE '%$cari_alat%');";
                                                    $result=mysqli_query($conn,$query) ;
                                                    $i = 0;
                                                    while ($row2=mysqli_fetch_array($result)){
                                                        $i++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $row2["id_alat"]; ?></td>
                                                    <td>
                                                        <?php if($row2["foto_alat"] != "" || !empty($row2["foto_alat"] || $row2["foto_alat"] != null)){ ?>
                                                            <div class="text-center">
                                                                <img src="images/<?php echo $row2["foto_alat"];?>" width="120px" height="120px" 
                                                                    class="img-responsive rounded" alt="">
                                                            </div>
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $row2["merk"]; ?> <?php echo $row2["type"]; ?></td>
                                                    <td><?php echo $row2["name_kat"]; ?></td>
                                                    <td>
                                                        <div class="btn btn-outline-primary btn-sm">
                                                            <a href="form_checklist.php?status_peminjaman=diambil&id_alat=<?php echo $row2["id_alat"];?>&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>&id_detail_masuk=<?php echo $row2["id_detail_masuk"];?>">
                                                                <i class='fa fa-clipboard-check fa-2x'></i> 
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Alat yang akan dipinjamkan <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>kategori Alat</th>
                                        <th>Foto Alat</th>
                                        <th>No. Inventaris</th>
                                        <th>Nama Alat</th>
                                        <th>Cheklist Pengambilan</th>
                                        <th>Cheklist Pengembalian</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php   
                                        $query1="SELECT d.*, a.`merk`, a.`type`, a.id_alat, a.foto_alat, k.`name_kat` FROM detail_peminjaman_diterima D, `detail_peminjaman_masuk` M, alat A, kategori K WHERE d.`id_detail_masuk` = m.`id_detail_masuk` AND m.id_peminjaman_masuk = '$id_peminjaman_masuk' AND d.`id_alat` = a.`id_alat` AND a.`id_kat` = k.`id_kat`;";
                                        $result1=mysqli_query($conn,$query1);
                                        $i = 0;
                                        while ($row2=mysqli_fetch_array($result1)){
                                            $i++;
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $row2["name_kat"]; ?></td>
                                        <td>
                                            <?php if($row2["foto_alat"] != "" || !empty($row2["foto_alat"] || $row2["foto_alat"] != null)){ ?>
                                                <div class="text-center">
                                                    <img src="images/<?php echo $row2["foto_alat"];?>" width="120px" height="120px" 
                                                        class="img-responsive rounded" alt="">
                                                </div>
                                            <?php } ?>
                                        </td>
                                        <td><?php echo $row2["id_alat"]; ?></td>
                                        <td><?php echo $row2["merk"]." ".$row2["type"]; ?></td>
                                        <td>
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-10">
                                                        Sudah Checklist Pengambilan
                                                    </div>
                                                    <div class="col-2">
                                                        <a href="form_checklist.php?id_check=<?php echo $row2["id_check_keluar"];?>">
                                                            <i class='fa fa-clipboard-check fa-2x'></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php
                                                if($row2["id_check_masuk"] != "" || $row2["id_check_masuk"] != null || !empty($row2["id_check_masuk"])){
                                            ?>
                                                <div class="container">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            Sudah Checklist Pengembalian
                                                        </div>
                                                        <div class="col-2">
                                                            <a href="form_checklist.php?id_check=<?php echo $row2["id_check_masuk"];?>">
                                                                <i class='fa fa-clipboard-check fa-2x'></i> 
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php }else{ ?>
                                                <div class="container">
                                                    <div class="row">
                                                        <div class="col-10">
                                                            Belum Checklist Pengembalian
                                                        </div>
                                                        <div class="col-2">
                                                            <a href="form_checklist.php?status_peminjaman=diambil&id_alat=<?php echo $row2["id_alat"];?>&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>&id_detail_masuk=<?php echo $row2["id_detail_masuk"];?>">
                                                                <i class='fa fa-clipboard-check fa-2x'></i> 
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <div class="btn btn-outline-danger btn-sm">
                                                <a href="delete_kategori.php?id_kat=<?php echo $row2["id_kat"];?>&id_masuk=<?php echo $row2["id_peminjaman_masuk"];?>">
                                                    <i class='fa fa-trash-o fa-2x'> </i> 
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="float-left">
                <a href="form_peminjaman_list.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>"class="btn btn-secondary btn-md active float-left" role="button" aria-pressed="true">
                    < Back
                </a> 
            </div> 
            <div class="float-right">
                <a href="form_peminjaman_jaminan.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>" class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">
                    Next >
                </a>
            </div>
            
        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>