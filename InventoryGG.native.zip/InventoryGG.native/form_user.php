<?php 
	include "connection.php";

    $id_user = $nama_user = $password = $username = $nia = $posisi =  $edit = "";
    
    if(isset($_GET['edit']) and isset($_GET['id_user'])){
        $edit       =   $_GET['edit'];
        $id_user    =   $_GET['id_user'];
        $result=mysqli_query($conn, "SELECT * FROM user WHERE id_user = $id_user");
        while ($row1=mysqli_fetch_array($result)){
            $nama_user      =   $row1["nama_user"];
            $username       =   $row1["username"];
            $password       =   $row1["password"];
            $nia            =   $row1["nia"];
            $posisi         =   $row1["posisi"];
        }
    }

    if(isset($_GET['nama_user']) and isset($_GET['password']) and isset($_GET['username'])){
        $nama_user  =   $_GET['nama_user'];
        $username   =   $_GET['username'];
        $password   =   $_GET['password'];
        $nia        =   $_GET["nia"];
        $posisi     =   $_GET["posisi"];

    }

    if(isset($_POST["submit"])){
        $id_user      =   $_POST["id_user"];
        $nama_user      =   $_POST["nama_user"];
        $username       =   $_POST["username"];
        $password       =   $_POST["password"];
        $nia            =   $_POST["nia"];
        $email            =   $_POST["email"];
        $nohp            =   $_POST["nohp"];
        $login_status         =   $_POST["login_status"];
        $status_anggota           =   $_POST['status_anggota'];
        if($status_anggota == "ketua umum" || $status_anggota == "wakil ketua" || $status_anggota == "departemen" || $status_anggota == "kepala divisi"){
            $posisi = "admin";
        }else{
            $posisi = "anggota";
        }

        $jumlah = count($_FILES['gambar']['name']);
            $file_name ="";
            if ($jumlah > 0) {
                for ($i=0; $i < $jumlah; $i++) { 
                    $file_name = $_FILES['gambar']['name'][$i];
                    $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                    move_uploaded_file($tmp_name, "images/".$file_name);				
                }
            }

        if($id_user != ""){
            if(($nama_user and $password and $username) != null){
                $query="INSERT INTO user set id_user = '$id_user', nama_user = '$nama_user', password = '$password', username = '$username', nia = '$nia',posisi = '$posisi', login_status = 'logout', status_anggota = '$status_anggota', no_telp = '$nohp', email = '$email', foto_anggota = '$file_name';";
                $sql_insert1 = mysqli_query($conn,$query);
                echo "<script>alert('Data Berhasil Ditambahkan')
                location.replace('tabel_user.php')</script>";
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }else{
            $query="UPDATE user set nama_user = '$nama_user', password = '$password', username = '$username', nia = '$nia',posisi = '$posisi', login_status = 'logout', status_anggota = '$status_anggota', no_telp = '$nohp', email = '$email', foto_anggota = '$file_name';";
            $sql_insert1 = mysqli_query($conn,$query);
            echo "<script>alert('Data Berhasil Diubah')
                location.replace('tabel_user.php')</script>";
        }
    }
        include 'header_admin.php';
    ?>
<body>

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Form User</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="dashboard_admin.php">Dashboard</a></li>
                                    <li><a href="#">Forms</a></li>
                                    <li class="active">Form User</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Isikan Data User</strong>
                                </div>
                                <div class="card-body card-block">
                                <form action="form_user.php" method="post" name="frm" encusername="multipart/form-data" class="form-horizontal">
                                        
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Id User</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="id_user" placeholder="Id User" class="form-control" value="<?php echo $id_user; ?>" disabled><small class="form-text text-muted">Id User</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan Nama User</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="nama_user" placeholder="Nama User" class="form-control" value="<?php echo $nama_user; ?>"><small class="form-text text-muted">Masukkan Nama User</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan Username</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="username" placeholder="Username" class="form-control" value="<?php echo $username; ?>"><small class="form-text text-muted">Masukkan Username    </small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan Password</label></div>
                                            <div class="col-12 col-md-9"><input type="password" id="passowrd-input" name="password" placeholder="Password" class="form-control" value="<?php echo $password; ?>"><small class="form-text text-muted">Masukkan Password</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan Nomor Induk Anggota</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="nia" placeholder="NIA" class="form-control" value="<?php echo $nia; ?>"><small class="form-text text-muted">Masukkan Nomor Induk Anggota</small></div>
                                        </div>
                                        <div class="row form-group" >
                                            <div class="col col-md-3">
                                                <label for="text-input" class=" form-control-label">Status Keanggotaan</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <select class="browser-default custom-select" name="status_anggota" placeholder="Dipinjam / Tidak Dipinjam">
                                                    <option <?php if($status_anggota == 'ketua umum'){echo 'selected';}?> value="ketua umum">Ketua Umum</option>
                                                    <option <?php if($status_anggota == 'wakil ketua 1'){echo 'selected';}?> value="wakil ketua 1">Wakil Ketua</option>
                                                    <option <?php if($status_anggota == 'rumah tangga'){echo 'selected';}?> value="rumah tangga">Rumah Tangga</option>
                                                    <option <?php if($status_anggota == 'departemen'){echo 'selected';}?> value="departemen">Departemen</option>
                                                    <option <?php if($status_anggota == 'kepala divisi'){echo 'selected';}?> value="kepala divisi">Kepala Divisi</option>
                                                    <option <?php if($status_anggota == 'anggota biasa'){echo 'selected';}?> value="anggota biasa">Anggota Biasa</option>
                                                    <option <?php if($status_anggota == 'anggota luar biasa'){echo 'selected';}?> value="anggota luar biasa">Anggota Luar Biasa</option>
                                                </select>
                                                <small class="form-text text-muted">Pilih Status Peminjaman</small>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan Email</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="email" placeholder="Posisi User" class="form-control" value="<?php echo $email; ?>"><small class="form-text text-muted">Masukkan Posisi User</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan No. Telephon</label></div>
                                            <div class="col-12 col-md-9"><input type="text" id="text-input" name="nohp" placeholder="Posisi User" class="form-control" value="<?php echo $nohp; ?>"><small class="form-text text-muted">Masukkan Posisi User</small></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label for="text-input" class=" form-control-label">Lampirkan Foto Alat</label>
                                            </div>
                                            <div class="col-12 col-md-9"><input type="file" id="text-input" name="gambar[]"placeholder="Choose file" class="form-control" value="">
                                                <?php
                                                    if(isset($_GET['id_check'])){
                                                        $result1=mysqli_query($conn,"SELECT * FROM checklist_record WHERE id_check = '$id_check' ");
                                                        while ($row2=mysqli_fetch_array($result1)){
                                                ?>
                                                <div class="btn btn-outline-primary btn-sm">
                                                    <?php echo $row2["foto_alat_check"];?>
                                                </div>
                                                <?php
                                                        }
                                                    }
                                                ?>
                                                <small class="help-block form-text">Lampirkan Foto Alat untuk mempermudah proses pengecekan</small>
                                            </div>
                                        </div>
                                        <!-- hidden input -->
                                        <input type="text" id="text-input" name="login_status" placeholder="" class="form-control" value="<?php echo $login_status; ?>" hidden>                      
                                        <input type="text" id="text-input" name="edit" placeholder="edit" class="form-control" value="<?php echo $edit; ?>" hidden>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    <div class="clearfix"></div>
        <?php
            include 'footer_admin.php'
        ?>
</body>
</html>
