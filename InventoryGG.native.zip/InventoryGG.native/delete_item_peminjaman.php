<?php
    include "connection.php";

    $id_detail_masuk=$_GET["id_detail_masuk"];
    $id_masuk=$_GET["id_masuk"];
    
    if($id_kat != null){
        $query="DELETE FROM detail_peminjaman_masuk where id_detail_masuk = $id_detail_masuk;";
        $delete=mysqli_query($conn,$query);
        echo "<script>alert('Data Berhasil Dihapus')
            location.replace('dash_item_peminjaman.php?id_masuk=$id_masuk')</script>";
    }else{
        echo "<script>alert('Data Gagal Dihapus')
        location.replace('dash_item_peminjaman.php?id_masuk=$id_masuk')</script>";
    }
?>