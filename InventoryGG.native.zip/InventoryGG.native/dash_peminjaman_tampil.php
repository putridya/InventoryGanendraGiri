<?php 
	include "connection.php";

    $id_peminjaman_masuk = $nama_instansi = $nama_kegiatan = $email_peminjam = $tgl_ambil = $tgl_kembali =  $no_wa = $status = null;

        $id_peminjaman_masuk = $_GET['id_peminjaman_masuk'];
        $query1 = "SELECT * FROM peminjaman_masuk WHERE id_peminjaman_masuk = '$id_peminjaman_masuk';";
        $result1=mysqli_query($conn,$query1) ;
        while ($row1=mysqli_fetch_array($result1)){
            $nama_instansi = $row1["nama_instansi"];
            $nama_kegiatan= $row1["nama_kegiatan"];
            $email_peminjam= $row1["email_peminjam"];
            $tgl_ambil= $row1["tgl_ambil"];
            $tgl_kembali= $row1["tgl_kembali"];
            $no_wa= $row1["no_wa"];
            $status= $row1["status"];
        }
        
    $query="SELECT D.*, k.name_kat FROM detail_peminjaman_masuk D, kategori K WHERE d.id_peminjaman_masuk = '$id_peminjaman_masuk' and k.id_kat = d.id_kat;"; 
    $result=mysqli_query($conn,$query) ; 

    $query2="SELECT k.`name_kat`, a.`merk`, a.`type` FROM detail_peminjaman_masuk M,detail_peminjaman_diterima D, alat A, kategori k WHERE m.`id_detail_masuk` = 'id_peminjaman_masuk' AND d.`id_detail_masuk` = m.`id_detail_masuk` AND d.`id_alat` = a.`id_alat` AND m.`id_kat` = k.`id_kat`;"; 
    $result2=mysqli_query($conn,$query2) ; 

    $title_header="Peminjaman | Inventory OPA Ganendra Giri";
    $home_active="";
    $peminjaman_active="active";
    $about_active="";
    include 'header_dashboard.php';
?>
<script>
    function printContent(el){
        var restorepage = document.body.innerHTML;
        var printcontent = document.getElementById(el).innerHTML;
        document.body.innerHTML = printcontent;
        window.print();
        document.body.innerHTML = restorepage;
    }
</script>
<body>
    <div class="breadcrumbs col-md-12 mt-3">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Peminjaman</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="content" >
        <div class="animated fadeIn">
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="card" id="div1">
                        <img src="images/KERTASKOPGG.png" class="card-img-top"
                            style="height: 100%; width: 100%; margin-left: auto; margin-right: auto;" alt="Kop Surat">
                        <div class="card-body card-block">
                            <h3>Data Peminjaman <?php echo $id_peminjaman_masuk; ?></h3>
                            <hr />
                            <div class="container">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input"
                                                    class=" form-control-label">Nama
                                                    Instansi</label></div>
                                            <div class="col-12 col-md-9">: <?php echo $nama_instansi; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="email-input"
                                                    class=" form-control-label">Email
                                                    Peminjam</label></div>
                                            <div class="col-12 col-md-9">: <?php echo $email_peminjam;?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input"
                                                    class=" form-control-label">Nama
                                                    Kegiatan</label></div>
                                            <div class="col-12 col-md-9">: <?php echo $nama_kegiatan ?></div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input"
                                                    class=" form-control-label">Tanggal Peminjaman</label></div>
                                            <div class="col-12 col-md-9">: <?php echo $tgl_ambil; ?> s/d
                                                <?php echo $tgl_kembali; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input"
                                                    class=" form-control-label">Nomor
                                                    WhatsApp Peminjam</label></div>
                                            <div class="col-12 col-md-9">: <?php echo $no_wa; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input"
                                                    class=" form-control-label">Status</label></div>
                                            <div class="col-12 col-md-9">: 
                                            <?php 
                                                if($status == 'baru'){
                                                    echo 'Belum disetujui';
                                                } else if ($status == 'disetujui'){
                                                    echo 'Telah disetujui';
                                                }else if ($status == 'diambil'){
                                                    echo 'Alat Telah Diambil';
                                                }else if ($status == 'dikembalikan'){
                                                    echo 'Alat Telah Dikembalikan';
                                                } ?></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col">
                                        <h4>List Permintaan</h4>
                                        <hr />
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Foto Alat</th>
                                                    <th>Jenis Alat</th>
                                                    <th>Permintaan</th>
                                                    <th>Disetujui</th>
                                                    <th>Dikeluarkan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $query="SELECT D.*, K.name_kat, K.foto_kat  FROM detail_peminjaman_masuk D,kategori K WHERE K.id_kat = D.id_kat AND id_peminjaman_masuk = '$id_peminjaman_masuk' ORDER BY D.`id_detail_masuk`";
                                                    $result=mysqli_query($conn,$query) ;
                                                    $i = 0;
                                                    while ($row2=mysqli_fetch_array($result)){
                                                        $i++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td>
                                                        <?php if($row2["foto_kat"] != "" || !empty($row2["foto_kat"] || $row2["foto_kat"] != null)){ ?>
                                                            <div class="text-center">
                                                                <img src="images/<?php echo $row2["foto_kat"];?>" width="120px" height="120px" 
                                                                    class="img-responsive rounded" alt="">
                                                            </div>
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $row2["name_kat"]; ?></td>
                                                    <td><?php echo $row2["jumlah"]; ?></td>
                                                    <td><?php echo $row2["jumlah_dikeluarkan"]; ?></td>
                                                    <td>
                                                        <?php
                                                            $id_detail_masuk = $row2["id_detail_masuk"];
                                                            $jum_kel="";
                                                            $queryKel="SELECT COUNT(*) AS jum_keluar FROM detail_peminjaman_diterima WHERE id_detail_masuk = '$id_detail_masuk'; ";
                                                            $resultKel=mysqli_query($conn,$queryKel) ;
                                                            while ($row6=mysqli_fetch_array($resultKel)){
                                                                $jum_kel = $row6["jum_keluar"];
                                                            }
                                                            echo $jum_kel;
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                        }
                                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="row" <?php if($status != "dikembalikan" && $status != "diambil"){echo "hidden";}?>>
                                    <div class="col">
                                        <h4>List Alat Dikeluarkan </h4>
                                        <hr />
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>kategori Alat</th>
                                                    <th>Foto Alat</th>
                                                    <th>No. Inventaris</th>
                                                    <th>Nama Alat</th>
                                                    <th>Kondisi</th>
                                                    <th>Keterangan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php   
                                                    $query1="SELECT d.*, a.`merk`, a.`type`, a.id_alat, a.foto_alat, k.`name_kat`, c.`kondisi`, c.`keterangan` FROM detail_peminjaman_diterima D, `detail_peminjaman_masuk` M, alat A, kategori K, `checklist_record` C WHERE d.`id_detail_masuk` = m.`id_detail_masuk` AND m.id_peminjaman_masuk = '$id_peminjaman_masuk' AND d.`id_check_keluar` = c.`id_check` AND d.`id_alat` = a.`id_alat` AND a.`id_kat` = k.`id_kat`;";
                                                    $result1=mysqli_query($conn,$query1);
                                                    $i = 0;
                                                    while ($row2=mysqli_fetch_array($result1)){
                                                        $i++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $row2["name_kat"]; ?></td>
                                                    <td>
                                                        <?php if($row2["foto_alat"] != "" || !empty($row2["foto_alat"] || $row2["foto_alat"] != null)){ ?>
                                                            <div class="text-center">
                                                                <img src="images/<?php echo $row2["foto_alat"];?>" width="120px" height="120px" 
                                                                    class="img-responsive rounded" alt="">
                                                            </div>
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $row2["id_alat"]; ?></td>
                                                    <td><?php echo $row2["merk"]." ".$row2["type"]; ?></td>
                                                    <td><?php echo $row2["kondisi"]; ?></td>
                                                    <td><?php echo $row2["keterangan"]; ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="row" <?php if($status != "dikembalikan"){echo "hidden";} ?>>
                                    <div class="col">
                                        <h4>List Alat Dikembalikan</h4>
                                        <hr />
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>kategori Alat</th>
                                                    <th>Foto Alat</th>
                                                    <th>No. Inventaris</th>
                                                    <th>Nama Alat</th>
                                                    <th>Kondisi</th>
                                                    <th>Keterangan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php   
                                                    $query1="SELECT d.*, a.`merk`, a.`type`, a.id_alat, a.foto_alat, k.`name_kat`, c.`kondisi`, c.`keterangan` FROM detail_peminjaman_diterima D, `detail_peminjaman_masuk` M, alat A, kategori K, `checklist_record` C WHERE d.`id_detail_masuk` = m.`id_detail_masuk` AND m.id_peminjaman_masuk = '$id_peminjaman_masuk' AND d.`id_check_masuk` = c.`id_check` AND d.`id_alat` = a.`id_alat` AND a.`id_kat` = k.`id_kat`;";
                                                    $result1=mysqli_query($conn,$query1);
                                                    $i = 0;
                                                    while ($row2=mysqli_fetch_array($result1)){
                                                        $i++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $row2["name_kat"]; ?></td>
                                                    <td>
                                                        <?php if($row2["foto_alat"] != "" || !empty($row2["foto_alat"] || $row2["foto_alat"] != null)){ ?>
                                                            <div class="text-center">
                                                                <img src="images/<?php echo $row2["foto_alat"];?>" width="120px" height="120px" 
                                                                    class="img-responsive rounded" alt="">
                                                            </div>
                                                        <?php } ?>
                                                    </td>
                                                    <td><?php echo $row2["id_alat"]; ?></td>
                                                    <td><?php echo $row2["merk"]." ".$row2["type"]; ?></td>
                                                    <td><?php echo $row2["kondisi"]; ?></td>
                                                    <td><?php echo $row2["keterangan"]; ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <button class="btn btn-outline-primary btn-sm" onclick="printContent('div1')"><i class="fas fa-print fa-2x"></i></button>
                </div>
            </div>
            
            <hr/>
            <?php 
                if(isset($_GET['id_peminjaman_masuk'])){
                    $jumlah_foto = 0;
                    $result=mysqli_query($conn,"SELECT COUNT(*) AS jum FROM foto_surat F, peminjaman_masuk P WHERE p.`id_peminjaman_masuk` = f.`id_peminjaman_masuk` AND f.`id_peminjaman_masuk` = '$id_peminjaman_masuk';");
                    while ($row1=mysqli_fetch_array($result)){
                        $jumlah_foto      =   $row1["jum"];
                    }
                    $hidden_foto = "hidden";
                    if($jumlah_foto != 0 ){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Surat <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <ol class="carousel-indicators">
                                                    <?php
                                                        for($i = 0; $i > $jumlah_foto; $i++){
                                                    ?>
                                                    <li data-target="#carouselExampleCaptions" data-slide-to="<?php echo $i; ?>" 
                                                        class="<?php if($jumlah_foto == 0){ echo 'active';} ?>"></li>
                                                    <?php } ?>
                                                </ol>
                                                <div class="carousel-inner">
                                                    <?php
                                                        $i = 0;
                                                        $result1=mysqli_query($conn,"SELECT * FROM foto_surat WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
                                                        while ($row2=mysqli_fetch_array($result1)){
                                                    ?>
                                                    <div class="carousel-item <?php if($i == 0){ echo 'active';} ?>">
                                                        <img src="images/<?php echo $row2["nama_file"];?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $row2["nama_file"];?></p>
                                                        </div>
                                                    </div>
                                                    <?php
                                                        $i++;    
                                                        }
                                                    ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button"
                                                    data-slide="prev">
                                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Previous</span>
                                                </a>
                                                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button"
                                                    data-slide="next">
                                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            
            <?php 
                if(isset($_GET['id_peminjaman_masuk'])){
                    $foto_jaminan = "";
                    $result=mysqli_query($conn,"SELECT foto_jaminan FROM peminjaman_masuk WHERE  id_peminjaman_masuk = '$id_peminjaman_masuk';");
                    while ($row1=mysqli_fetch_array($result)){
                        $foto_jaminan      =   $row1["foto_jaminan"];
                    }
                    $hidden_foto = "hidden";
                    if($foto_jaminan != "" || $foto_jaminan != null || !empty($foto_jaminan)){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Jaminan Peminjam <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active">
                                                        <img src="images/<?php echo $foto_jaminan;?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $foto_jaminan;?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
    
        </div><!-- .animated -->
    </div><!-- .content -->


    <div class="clearfix"></div>
    <?php
            include 'footer_dashboard.php'
        ?>
</body>

</html>