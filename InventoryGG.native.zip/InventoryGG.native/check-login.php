<?php
// mengaktifkan session php
session_start();
 
// menghubungkan dengan koneksi
include 'connection.php';
 
// menangkap data yang dikirim dari form
$username = $_POST['username'];
$password = $_POST['password'];
$status ="";
$login_status = "";

    $query1 = "SELECT * FROM user WHERE username = '$username' and password='$password';";
    $result1=mysqli_query($conn,$query1);
    while ($row1=mysqli_fetch_array($result1)){
        $status = $row1["posisi"];
        $login_status = $row1["login_status"];
    }

if($status != "" && $login_status != ""){
    $query2 = "UPDATE user set login_status = 'login' WHERE username = '$username'";
    $result2=mysqli_query($conn,$query2);
    $_SESSION['username'] = $username;
    $_SESSION['status'] = $status;
    header("location:dashboard_admin.php");
}else{
	header("location:login.php?pesan=gagal");
}
?>