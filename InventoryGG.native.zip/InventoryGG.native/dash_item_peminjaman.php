<?php 
	include "connection.php";

    $id_peminjaman_masuk = $id_detail_masuk = $id_kat = $jumlah = $name_kat = $query = $result = null;
    
    if(isset($_GET['id_peminjaman_masuk'])){
        $id_peminjaman_masuk = $_GET['id_peminjaman_masuk'];
    }
    
    if(isset($_GET['edit']) and isset($_GET['id_peminjaman_masuk']) and isset($_GET['id_detail_masuk'])){
        $edit=$_GET['edit'];
        $id_peminjaman_masuk = $_GET['id_peminjaman_masuk'];
        $id_detail_masuk = $_GET['id_detail_masuk'];
        $query1 = "SELECT * FROM detail_peminjaman_masuk WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' AND `id_detail_masuk` = '$id_detail_masuk' ORDER BY `id_detail_masuk`;";
        $result1=mysqli_query($conn,$query1) or die (mysqli_error());
        while ($row1=mysqli_fetch_array($result1)){
            $id_kat = $row1["id_kat"];
            $jumlah= $row1["jumlah"];
        }
    }

    if(isset($_GET["id_peminjaman_masuk"]) and isset($_GET["id_kat"]) and isset($_GET["jumlah"]) and issert($_GET["id_detail_masuk"])){
        $id_detail_masuk = $_GET['id_detail_masuk'];
        $id_peminjaman_masuk=$_GET["id_peminjaman_masuk"];
        $id_kat=$_GET["id_kat"];
        $jumlah = $_GET["jumlah"];
    }

    if(isset($_POST["reset"])){
        $id_peminjaman_masuk=$_POST["id_peminjaman_masuk"];
        $id_detail_masuk = $_POST['id_detail_masuk'];
        $id_kat=$_POST["id_kat"];
        $jumlah = $_POST["jumlah"];
        $no_wa= $_POST["no_wa"];
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('detail_peminjaman_masuk.php?id_peminjaman_masuk=$id_masuk');
                } else {
                    location.replace('form_peminjaman_masuk.php?id_peminjaman_masuk=$id _masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk');
                }
            </script>";
        
    }

    if(isset($_POST["submit"])){
        $id_peminjaman_masuk=$_POST["id_peminjaman_masuk"];
        $id_kat=$_POST["id_kat"];
        $jumlah = $_POST["jumlah"];
        $id_detail_masuk=$_POST["id_detail_masuk"];
        $sql_insert1 = false;

        if($id_detail_masuk != null){
            if(($id_peminjaman_masuk and $id_kat and $jumlah and $id_detail_masuk) != null){
                $query1="UPDATE detail_peminjaman_masuk SET id_kat='$id_kat', jumlah='$jumlah' WHERE id_detail_masuk = '$id_detail_masuk';";
                $sql_insert1 = mysqli_query($conn,$query1) or die (mysqli_error());
            }else{
                echo "<script>alert('Ada data yang kosong')location.replace('dash_item_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }else{
            if(($id_peminjaman_masuk and $id_kat and $jumlah) != null){
                $query1="INSERT INTO detail_peminjaman_masuk (`id_peminjaman_masuk`,`id_kat`,`jumlah`) VALUES ('".$id_peminjaman_masuk."','".$id_kat."','".$jumlah."');";
                $sql_insert1 = mysqli_query($conn,$query1) or die (mysqli_error());
            }else{
                echo "<script>alert('Ada data yang kosong')
                location.replace('dash_item_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }

        if($sql_insert1){
            echo "<script>alert('Data Berhasil Ditambahkan')
            location.replace('dash_item_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }else{
            echo "<script>alert('Data Gagal Ditambahkan')
            location.replace('dash_item_peminjaman.php?id_peminjaman_masuk=$id_peminjaman_masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk')</script>";
        }
                
            
    }

    if(isset($_POST["reset"])){
        $id_peminjaman_masuk = $id_detailmasuk = $id_kat = $jumlah = $name_kat = $query = null;
    }
?>

<?php
        $title_header="Peminjaman | Inventory OPA Ganendra Giri";
        $home_active="";
        $peminjaman_active="active";
        $about_active="";
        include 'header_dashboard.php';
    ?>

<body>

    <div class="breadcrumbs col-md-12 mt-3">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Peminjaman</h1>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Dashboard</a></li>
                                <li><a href="#">Forms</a></li>
                                <li class="active">Form Peminjaman</li>
                            </ol>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Pilih item yang akan dipinjam <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <form action="dash_item_peminjaman.php" method="post" name="frm" enctype="multipart/form-data"
                                class="form-horizontal">

                                <div class="row form-group">
                                    <div class="col col-md-3"><label for="text-input" class=" form-control-label">Jenis Alat</label></div>
                                    <div class="col-12 col-md-9"><select name="id_kat" class="form-control">
                                    <?php
                                        $query="SELECT * FROM kategori";
                                        $sql=mysqli_query($conn,$query);
                                        while ($row=mysqli_fetch_array($sql)) {
                                            $select = "";
                                            if ($row['id_kat']==$id_kat) {
                                                $select="selected";
                                            }
                                    ?>
                                    <option <?php echo $select; ?> value="<?php echo $row['id_kat'];?>"><?php echo $row['name_kat']; ?></option>
                                    <?php
                                        }
                                    ?>
                                    </select><small class="form-text text-muted">pilih jenis alat</small></div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-3"><label for="text-input" class=" form-control-label">Masukkan jumlah</label></div>
                                    <div class="col-12 col-md-9"><input type="number" name="jumlah" class="form-control"
                                            value="<?php echo $jumlah; ?>" placeholder="Masukkan jumlah Peminjaman"><small class="help-block form-text">Masukkan jumlah yang akan dipinjam</small></div>
                                    <input type="text"  name="id_peminjaman_masuk" hidden="hidden"
                                        class="form-control" value="<?php echo $id_peminjaman_masuk; ?>">
                                    <input type="text" name="id_detail_masuk" hidden="hidden"
                                        class="form-control" value="<?php echo $id_detail_masuk; ?>">
                                </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                <i class="fa fa-dot-circle-o"></i> Submit
                            </button>
                            <button type="reset" class="btn btn-danger btn-sm" name="reset">
                                <i class="fa fa-ban"></i> Reset
                            </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Alat Yang akan dipinjam <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Jenis Alat</th>
                                        <th>Jumlah</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                        $query="SELECT D.*, K.name_kat FROM detail_peminjaman_masuk D,kategori K WHERE K.id_kat = D.id_kat AND id_peminjaman_masuk = '$id_peminjaman_masuk' ORDER BY D.`id_detail_masuk`;";
                                        $result=mysqli_query($conn,$query) or die (mysqli_error());
                                        $i = 0;
                                        while ($row2=mysqli_fetch_array($result)){
                                            $i++;
                                ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><?php echo $row2["name_kat"]; ?></td>
                                        <td><?php echo $row2["jumlah"]; ?></td>
                                        <td>
                                            <div class="btn btn-outline-primary btn-sm"><a href="dash_item_peminjaman.php?edit=true&id_masuk=<?php echo $row2["id_peminjaman_masuk"];?>&id_detail_masuk=<?php echo $row2["id_detail_masuk"];?>"> <i class='fa fa-pencil fa-2x'> </i> </a></div>
                                            <div class="btn btn-outline-danger btn-sm"><a href="delete_detail_peminjaman.php?id_masuk=<?php echo $row2["id_peminjaman_masuk"];?>&id_peminjman_masuk=<?php echo $row2["id_detail_masuk"];?>&user=peminjam"> <i class='fa fa-trash-o fa-2x'> </i> </a></div>
                                        </td>
                                    </tr>
                                <?php
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <!-- BUTTON BACK -->
            <div class="float-left">
                <a href="dash_peminjaman.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>&edit=true" class="btn btn-secondary btn-md active float-left" 
                    role="button" aria-pressed="true">
                    < Back
                </a> 
            </div> 

            <!-- BUTTON NEXT -->
            <?php if(isset($_GET['id_peminjaman_masuk'])){ ?>
            <div class="float-right">
                <a href="dash_peminjaman_tampil.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>"
                    class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">
                    Print >
                </a>
            </div>
            <?php } ?>
                </div>
            </div>
        </div>
    </div>

    
    </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
    <?php
            include 'footer_dashboard.php';
        ?>
</body>

</html>