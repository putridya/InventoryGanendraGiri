<?php 
    include "connection.php";
    include 'header_admin.php';

    $id_check = $tgl_checklist = $kondisi = $id_alat = $keterangan = $id_user = $dipinjam = $peminjaman = $id_detail_masuk = $foto_alat = $id_peminjaman_masuk =  $edit  = $id_detail = $disAlatPinjam = $nama_user= $disIdAlat = "";
    $id_check_last = $tgl_checklist_last = $id_alat_last = $kondisi_last = $keterangan_last = $foto_alat_check_last = $nama_user_last = $dipinjam_last = $id_peminjaman_masuk_last = $tgl_terbaru_last = $id_checklist_group = "";   
    $dateNow= date("Y-m-d");
    $header_check = "Checklist Alat ";
    $disAlatPinjam = $disIdAlat = "hidden";
    $kondisi_last = "valid";

    if(isset($_GET['status_peminjaman']) and isset($_GET['id_alat']) and isset($_GET['id_peminjaman_masuk']) and isset($_GET['id_detail_masuk'])){
        $id_alat = $_GET['id_alat'];
        $peminjaman = $_GET['status_peminjaman'];
        $id_peminjaman_masuk = $_GET['id_peminjaman_masuk'];
        $id_detail_masuk = $_GET['id_detail_masuk'];
        $disAlatPinjam = $disIdAlat = "";
    }

    if(isset($_GET['id_alat'])){
        $id_alat = $_GET['id_alat'];
        $tgl_checklist = $dateNow;
    }

    if(isset($_GET['id_alat']) and isset($_GET['delete'])){
        $id_user = $username;
        $id_alat        =   $_GET['id_alat'];
        $tgl_checklist = $dateNow;
        $kondisi = "diputihkan";
        $disAlatPinjam = $disIdAlat = "hidden";
    }

    
    if(isset($_GET['id_check'])){
        $id_check   =   $_GET['id_check'];
        $result=mysqli_query($conn, "SELECT * FROM checklist_record WHERE id_check = $id_check");
        while ($row1=mysqli_fetch_array($result)){
            $tgl_checklist  =   $row1["tgl_checklist"];
            $id_alat        =   $row1["id_alat"];
            $kondisi        =   $row1["kondisi"];
            $keterangan     =   $row1["keterangan"];
            $username        =   $row1["username"];
            $status_peminjaman       =   $row1["status_peminjaman"];
            $id_peminjaman_masuk      =   $row1["id_peminjaman_masuk"];
            $id_checklist_group      =   $row1["id_checklist_group"];

        }
    }

    if(isset($_POST["submit"])){
        $id_check       =   $_POST["id_check"];
        $tgl_checklist  =   $_POST["tgl_checklist"];
        $id_alat        =   $_POST["id_alat"];
        $kondisi        =   $_POST["kondisi"];
        $keterangan     =   $_POST["keterangan"];
        $status_peminjaman = $_POST["status_peminjaman"];
        $username_check = $_POST["username_check"];
        $id_detail_masuk = $_POST["id_detail_masuk"];
        $id_peminjaman_masuk = $_POST["id_peminjaman_masuk"];
        $id_checklist_group = $_POST["id_checklist_group"];

        if($id_check == "" || empty($id_check)){

            $jumlah = count($_FILES['gambar']['name']);
            $file_name ="";
            if ($jumlah > 0) {
                for ($i=0; $i < $jumlah; $i++) { 
                    $file_name = $_FILES['gambar']['name'][$i];
                    $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                    move_uploaded_file($tmp_name, "images/".$file_name);				
                }
            }

            if(($tgl_checklist and $kondisi and $id_alat and $username_check) != null){
                $query="INSERT INTO checklist_record set id_check = '$id_check', tgl_checklist = '$tgl_checklist', kondisi = '$kondisi', 
                            id_alat = '$id_alat',keterangan = '$keterangan', status_peminjaman = '$status_peminjaman', 
                            username = '$username_check', id_peminjaman_masuk = '$id_peminjaman_masuk', 
                            id_checklist_group = '$id_checklist_group', foto_alat_check = '$file_name' ;";
                $sql_insert1 = mysqli_query($conn,$query);
                if(($id_peminjaman_masuk and $id_detail_masuk) != "" and $sql_insert1){
                    $id_check_max = "";
                    $resultChecklist=mysqli_query($conn,"SELECT MAX(`id_check`) AS id_check_max FROM checklist_record; ") ;
                    while ($row6=mysqli_fetch_array($resultChecklist)){
                        $id_check_max = $row6["id_check_max"];
                    }
                    $insert_tr = "";
                    $result_ins=mysqli_query($conn,"SELECT COUNT(*) AS jumlah FROM `detail_peminjaman_diterima` WHERE `id_check_keluar` LIKE '%$id_check_max%' OR `id_check_masuk` LIKE '%$id_check_max%'; ") ;
                    while ($row6=mysqli_fetch_array($result_ins)){
                        $insert_tr = $row6["jumlah"];
                    }
                    if($insert_tr == "0" || $insert_tr == 0 || empty($insert_tr) || $insert_tr == ""){
                        echo "<script>alert('Berhasil Menambahkan Data Checklist peminjaman')
                            location.replace('insert_detail_peminjaman_diterima.php?id_check=$id_check_max&id_peminjaman_masuk=$id_peminjaman_masuk&id_detail_masuk=$id_detail_masuk&status_peminjaman=$status_peminjaman&id_alat=$id_alat')</script>";
                    }else{
                        echo "<script>alert('Berhasil Menambahkan Data Checklist')
                                location.replace('alat.php')</script>";
                    }
                    
                }else if($sql_insert1){
                    echo "<script>alert('Berhasil Menambahkan Data Checklist')
                            location.replace('alat.php')</script>";
                }else{
                    echo "<script>alert('Gagal Menambahkan Data Checklist')
                        location.replace('form_checklist.php?id_alat=$id_alat&id_peminjaman_masuk=$id_peminjaman_masuk&id_checklist_group=$id_checklist_group&id_detail_masuk=$id_detail_masuk&status_peminjaman=$status_peminjaman')</script>";
                }
            }else{
                echo "<script>alert('Gagal Menambahkan Data Checklist. Ada Data yang tidak ditemukan.')
                        location.replace('form_checklist.php?id_alat=$id_alat&id_peminjaman_masuk=$id_peminjaman_masuk&id_checklist_group=$id_checklist_group&id_detail_masuk=$id_detail_masuk&status_peminjaman=$status_peminjaman')</script>";
            }
        }else{
            $query="UPDATE checklist_record set tgl_checklist = '$tgl_checklist', kondisi = '$kondisi', id_alat = '$id_alat', 
                        keterangan = '$keterangan', status_peminjaman = '$status_peminjaman', username = '$username_check', 
                        id_peminjaman_masuk = '$id_peminjaman_masuk', id_checklist_group = '$id_checklist_group', 
                        foto_alat_check = '$file_name' where id_check = $id_check;";
            $sql_insert1 = mysqli_query($conn,$query);

            if($id_peminjaman_masuk != ""){
                echo "<script>alert('Berhasil Mengubah Data Checklist')
                        location.replace('form_peminjaman_list_alat.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }else{
                echo "<script>alert('Berhasil Mengubah Data Checklist')
                    location.replace('alat.php')</script>";
            }
        }
    }

    $result=mysqli_query($conn, "SELECT a.*, k.`name_kat` FROM alat A, kategori K WHERE id_alat = '$id_alat' AND k.`id_kat` = a.`id_kat`;");
        while ($row1=mysqli_fetch_array($result)){
            $type           =   $row1["type"];
            $merk           =   $row1["merk"];
            $id_kat         =   $row1["id_kat"];
            $tgl_masuk      =   $row1["tgl_masuk"];
            $tgl_keluar     =   $row1["tgl_keluar"];
            $username        =   $row1["username"];
            $name_kat       =   $row1["name_kat"];
            $foto_alat      =   $row1["foto_alat"];     
        }

        $result=mysqli_query($conn, "SELECT C.*,MAX(tgl_checklist) AS tgl_terbaru FROM checklist_record C WHERE id_alat = '$id_alat' ;");
        while ($row1=mysqli_fetch_array($result)){
            $id_check_last           =   $row1["id_check"];
            $tgl_checklist_last      =   $row1["tgl_checklist"];
            $id_alat_last            =   $row1["id_alat"];
            $kondisi_last            =   $row1["kondisi"];
            $keterangan_last         =   $row1["keterangan"];
            $dipinjam_last         =   $row1["status_peminjaman"];
            $id_peminjaman_masuk_last          =   $row1["id_peminjaman_masuk"];
            $tgl_terbaru_last        =   $row1["tgl_terbaru"]; 
            $foto_alat_check_last        =   $row1["foto_alat_check"];            
        }

?>
<body>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1><?php echo $header_check; echo $dateNow;?></h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="alat.php">Data Alat Checklist</a></li>
                                <li class="active">Form Checklist</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Data Alat</strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row">
                                    <div class="col">
                                        <h3>Data Alat</h3>
                                        <hr>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Nomor Inventaris</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $id_alat; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Merk</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $merk; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tipe</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $type; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Kategori</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $name_kat; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tanggal Masuk</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $tgl_masuk; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tanggal Keluar</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $tgl_keluar; ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <?php
                                                $nia = "";
                                                $queryKel="SELECT * FROM user WHERE id_user = '$id_user'; ";
                                                $resultKel=mysqli_query($conn,$queryKel) ;
                                                $i = 0;
                                                while ($row6=mysqli_fetch_array($resultKel)){
                                                    $nama_user = $row6["nama_user"];
                                                    $nia = $row6["nia"];
                                                }
                                            ?>
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Petugas</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $nama_user; echo " "; echo $nia;?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Foto</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; if($foto_alat != ""){?>
                                                <div class="text-center">
                                                    <img src="images/<?php echo $foto_alat;?>" width="120px" height="120px" class="img-responsive rounded" alt="">
                                                </div>
                                            <?php } ?>
                                            </div>
                                        </div>                                        
                                    </div>
                                    <div class="col">
                                    <h3>Data Checklist Terbaru</h3>
                                    <hr>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Id Checklist</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $id_check_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Tanggal Checklist</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $tgl_checklist_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Kondisi Alat</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $kondisi_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Keterangan Alat</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $keterangan_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Petugas Checklist</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $nama_user_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Status Peminjaman</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $dipinjam_last ?></div>
                                        </div>                                               
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Nomor Peminjaman</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; echo $id_peminjaman_masuk_last ?></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label for="text-input" class=" form-control-label">Kondisi Alat ketika Checklist</label></div>
                                            <div class="col-12 col-md-9"><?php echo ": "; if($foto_alat_check_last != ""){?>
                                                <div class="text-center">
                                                    <img src="images/<?php echo $foto_alat_check_last;?>" width="120px" height="120px" class="img-responsive rounded" alt="">
                                                </div>
                                            <?php } ?>
                                            </div>
                                        </div>     
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Isikan Data Checklist Alat <?php echo $id_alat; ?></strong>
                        </div>
                        <form action="form_checklist.php" method="post" name="frm" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="container">
                                    <div class="row">
                                        <div class="col">       
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Id Checklist</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="id_check" placeholder="Id Checklist" class="form-control" 
                                                        value="<?php echo $id_check; ?>" disabled>
                                                    <small class="form-text text-muted">Id Check akan terisi otomatis.</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Petugas Checklist</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="username_check" placeholder="Username" class="form-control" 
                                                        value="<?php echo $_SESSION['username']; ?>" disabled>
                                                    <small class="form-text text-muted">Username Petugas Checklist akan terisi otomatis</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Masukkan Tanggal Checklist</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" id="date-input" name="tgl_checklist" placeholder="Tanggal Checklist" class="form-control" 
                                                        value="<?php echo $tgl_checklist; ?>">
                                                    <small class="form-text text-muted">Masukkan Tanggal Checklist</small>
                                                </div>
                                            </div>
                                            <div class="row form-group" hidden >
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Masukkan Id Alat</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="id_alat" placeholder="Id Alat" class="form-control" 
                                                        value="<?php echo $id_alat; ?>">
                                                    <small class="form-text text-muted">Masukkan Id Alat</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Masukkan Kondisi Alat</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select class="browser-default custom-select" name="kondisi" placeholder="Masukkan Kondisi Alat">
                                                        <?php $kon = ""; if($id_alat == "" || empty($id_alat)){$kon = $kondisi_last;}else{$kon = $kondisi;}?>
                                                        <option <?php if($kon == 'valid'){echo 'selected';}?> value="valid">Valid</option>
                                                        <option <?php if($kon == 'rusak'){echo 'selected';}?> value="rusak">Rusak</option>
                                                        <option <?php if($kon == 'hilang'){echo 'selected';}?> value="hilang">Hilang</option>
                                                        <option <?php if($kon == 'diputihkan'){echo 'selected';}?> value="diputihkan">Diputihkan</option>
                                                    </select>
                                                    <small class="form-text text-muted">Masukkan Kondisi Alat</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Masukkan Keterangan Alat</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="keterangan" placeholder="Keterangan" class="form-control" 
                                                    value="<?php echo $keterangan; ?>">
                                                    <small class="form-text text-muted">Masukkan Keterangan Alat</small>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Lampirkan Foto Alat</label>
                                                </div>
                                                <div class="col-12 col-md-9"><input type="file" id="text-input" name="gambar[]"placeholder="Choose file" class="form-control" value="">
                                                    <?php
                                                        if(isset($_GET['id_check'])){
                                                            $result1=mysqli_query($conn,"SELECT * FROM checklist_record WHERE id_check = '$id_check' ");
                                                            while ($row2=mysqli_fetch_array($result1)){
                                                    ?>
                                                    <div class="btn btn-outline-primary btn-sm">
                                                        <?php echo $row2["foto_alat_check"];?>
                                                    </div>
                                                    <?php
                                                            }
                                                        }
                                                    ?>
                                                    <small class="help-block form-text">Lampirkan Foto Alat untuk mempermudah proses pengecekan</small>
                                                </div>
                                            </div>
                                            <div class="row form-group" <?php if($peminjaman == "" || empty($peminjaman)){echo "hidden";}?>>
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Status Peminjaman</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select class="browser-default custom-select" name="status_peminjaman" placeholder="Dipinjam / Tidak Dipinjam">
                                                        <option <?php if($peminjaman == 'diambil'){echo 'selected';}?> value="diambil">Diambil</option>
                                                        <option <?php if($peminjaman == 'dikembalikan'){echo 'selected';}?> value="dikembalikan">Dikembalikan</option>
                                                    </select>
                                                    <small class="form-text text-muted">Pilih Status Peminjaman</small>
                                                </div>
                                            </div>
                                            <div class="row form-group" <?php if($id_peminjaman_masuk == "" or empty($id_peminjaman_masuk)){echo "hidden";}?>>
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Nomor Peminjaman</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="id_peminjaman_masuk" placeholder="Id Peminjaman Masuk" class="form-control" 
                                                        value="<?php echo $id_peminjaman_masuk; ?>" disabled>
                                                    <small class="form-text text-muted">Masukkan Nomor Peminjaman</small>
                                                </div>
                                            </div>
                                            <div class="row form-group" <?php if($id_checklist_group == "" or empty($id_checklist_group)){echo "hidden";}?>>
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Id Checklist Group</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="id_checklist_group" placeholder="Id Checklist Group" class="form-control" 
                                                        value="<?php echo $id_checklist_group; ?>" disabled>
                                                    <small class="form-text text-muted">Masukkan Nomor Peminjaman</small>
                                                </div>
                                            </div>
                                            <input type="text" id="text-input" name="id_detail_masuk" placeholder="" class="form-control" value="<?php echo $id_detail_masuk; ?>" hidden="hidden">
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                    <i class="fa fa-dot-circle-o"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <?php 
                if(isset($id_check)){
                    $foto_jaminan = "";
                    $result=mysqli_query($conn,"SELECT foto_alat_check FROM checklist_record WHERE  id_check = '$id_check';");
                    while ($row1=mysqli_fetch_array($result)){
                        $foto_jaminan      =   $row1["foto_alat_check"];
                    }
                    $hidden_foto = "hidden";
                    if($foto_jaminan != "" || $foto_jaminan != null || !empty($foto_jaminan)){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Alat Checklist</strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active">
                                                        <img src="images/<?php echo $foto_jaminan;?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $foto_jaminan;?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
            
            <?php if($id_peminjaman_masuk != "") { ?>
            <div class="float-left">
                <a href="form_peminjaman_list_alat.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>"
                class="btn btn-secondary btn-md active float-left" role="button" aria-pressed="true">< Back</a> 
            </div>
            <?php } ?>

        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
        <?php
            include 'footer_admin.php'
        ?>
</body>
</html>
