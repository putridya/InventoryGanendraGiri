<?php 
    include "connection.php";
    include "header_admin.php";

    $cari;
    $query="SELECT A.*, k.`name_kat`, u.`nama_user` FROM alat A, kategori K, USER U WHERE a.`id_kat` = k.`id_kat` AND a.`username` = u.`username` ORDER BY `tgl_masuk` DESC;"; //query vendor

    if(isset($_GET["search"])){
        $cari=$_GET["text_search"];
        $query="SELECT * FROM alat WHERE `id_alat` LIKE '%$cari%' OR `merk` LIKE '%$cari%' OR 'type' LIKE '%$cari%';";
    }
    
    $result=mysqli_query($conn,$query);

?>
<html>

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Tabel Alat</h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li class="active">Tabel Alat</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Data Tabel</strong>
                                <a href="form_alat.php" class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">Form Alat Baru</a>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>No. INV</th>
                                            <th>Gambar</th>
                                            <th>Nama Alat</th>
                                            <th>Kategori</th>
                                            <th>Tanggal Masuk</th>
                                            <th>Tgl Keluar</th>
                                            <th>Petugas</th>
                                            <th>ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i = 0;
                                        while ($row1=mysqli_fetch_array($result)){
                                            $i++;
                                    ?>
                                        <tr>
                                            <td><?php echo $i ?></td>
                                            <td><?php echo $row1["id_alat"]; ?></td>
                                            <td>
                                                <?php if($row1["foto_alat"] != "" || !empty($row1["foto_alat"] || $row1["foto_alat"] != null)){ ?>
                                                    <div class="text-center">
                                                        <img src="images/<?php echo $row1["foto_alat"];?>" width="120px" height="120px" 
                                                            class="img-responsive rounded" alt="">
                                                    </div>
                                                <?php } ?>
                                            </td>
                                            <td><?php echo $row1["merk"]." ".$row1["type"]; ?></td>
                                            <td><?php echo $row1["name_kat"]; ?></td>
                                            <td><?php echo $row1["tgl_masuk"]; ?></td>
                                            <td><?php echo $row1["tgl_keluar"]; ?></td>
                                            <td><?php echo $row1["nama_user"]; ?></td>
                                            <td> 
                                                <!-- <div class="btn btn-outline-primary btn-sm"><a  href="tampil_barang_masuk.php?id_alat=<?php echo $row1["id_alat"];?>"> <i class="fas fa-book-open fa-2x"></i> </a></div> -->
                                                <div class="btn btn-outline-primary btn-sm"><a  href="form_alat.php?edit=true&id_alat=<?php echo $row1["id_alat"];?>"> <i class='fa fa-pencil fa-2x'> </i> </a></div>
                                                <div class="btn btn-outline-danger btn-sm"><a  href="form_checklist.php?delete=true&id_alat=<?php echo $row1["id_alat"];?>"> <i class='fa fa-trash-o fa-2x'> </i> </a></div>
                                                <div class="btn btn-outline-danger btn-sm"><a  href="form_checklist.php?id_alat=<?php echo $row1["id_alat"];?>"> <i class='fas fa-clipboard-check fa-2x'> </i> </a></div>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


        <div class="clearfix"></div>

        <?php
            include 'footer_admin.php'
        ?>

</body>
</html>
