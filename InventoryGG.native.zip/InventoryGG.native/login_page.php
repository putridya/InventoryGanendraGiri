<?php

include 'connection.php';

$msg = '';

$username = $password = null;

if (!isset($username) || !isset($password)) {
header( "Location: index.php" );
}

elseif (empty($username) || empty($password)) {
header( "Location: index.php" );
}
else{

$username = addslashes($_POST['username']);
$password = md5($_POST['password']);

$result=mysqli_query("select * from user where username= '$username' AND password='$password'", $conn);

// //melihat apakah username dan password yang dimasukkan benar
$rowCheck = mysqli_num_rows($result);

//jika benar maka
if($rowCheck > 0){
    while($row = mysqli_fetch_array($result)){

    //mulai session dan register variabelnya
    session_start();
    session_register('username');

    //Memberitahu jika login sukses
    echo 'login berhasil..!!';

    //redirect ke halaman lain untuk lebih memastikan
    header( "Location: loginok.php" );
    }

}
else {

//jika $rowCheck = 0, berarti username atau password salah, atau tidak terdaftar di database

echo 'Invalid username or password, coba lagi deh..' ;
}

?>

<html>
    <body>
        <div class = "container">
        
        <form class = "form-signin" role = "form" action = "login_page.php" method = "post">
            <h4 class = "form-signin-heading"><?php echo $msg; ?></h4>
            <input type = "text" class = "form-control" name = "username" placeholder = "Username" required autofocus></br>
            <input type = "password" class = "form-control" name = "password" placeholder = "Password" required>
            <button class = "btn btn-lg btn-primary btn-block" type = "submit" name = "login">Login</button>
        </form>
            
        Click here to clean <a href = "logout.php" title = "Logout">Session.
        
         </div> 
    </body>
</html>