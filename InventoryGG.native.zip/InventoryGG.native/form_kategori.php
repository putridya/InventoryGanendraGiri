<?php 
	include "connection.php";

    $id_kat = $name_kat = $edit = "";
    
    if(isset($_GET['id_kat'])){
        $id_kat     =   $_GET['id_kat'];
        $name_kat   =   $_GET['name_kat'];
        $result=mysqli_query($conn, "SELECT * FROM kategori WHERE id_kat = $id_kat ");
        while ($row1=mysqli_fetch_array($result)){
            $name_kat   =   $row1["name_kat"];
        }
    }

    if(isset($_POST["submit"])){
        $id_kat     =   $_POST["id_kat"];
        $name_kat   =   $_POST["name_kat"];

        if($id_kat != "" || $id_kat != null){
            $jumlah = count($_FILES['gambar']['name']);
            $file_name ="";
            if ($jumlah > 0) {
                for ($i=0; $i < $jumlah; $i++) { 
                    $file_name = $_FILES['gambar']['name'][$i];
                    $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                    move_uploaded_file($tmp_name, "images/".$file_name);				
                }
            }

            if(($id_kat and $name_kat) != null){
                $query="INSERT INTO kategori set id_kat = '$id_kat',name_kat = '$name_kat', foto_kat = '$file_name';";
                $sql_insert1 = mysqli_query($conn,$query);
                echo "<script>alert('Data Berhasil Ditambahkan')
                location.replace('tabel_kategori.php')</script>";
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }else{
            $query="UPDATE kategori set name_kat = '$name_kat', foto_kat = '$file_name' where id_kat = $id_kat;";
            $sql_insert1 = mysqli_query($conn,$query);
            echo "<script>alert('Data Berhasil Diubah')
                location.replace('tabel_kategori.php')</script>";
        }
    }

    include 'header_admin.php';
?>
<body>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Kategori</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="tabel_kategori.php">Tabel Kategori</a></li>
                                <li class="active">Form Kategori</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Isikan Data Kategori</strong>
                        </div>
                        <form action="form_kategori.php" method="post" name="frm" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="container">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Id Kategori</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="id_kat" placeholder="Kategori" class="form-control" value="<?php echo $id_kat;?>" disabled>
                                            <small class="form-text text-muted">Masukkan Nama Kategori</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Masukkan Nama Kategori Baru</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="name_kat" placeholder="Kategori" class="form-control" value="<?php echo $name_kat; ?>">
                                            <small class="form-text text-muted">Masukkan Nama Kategori</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Lampirkan Foto kategori</label>
                                        </div>
                                        <div class="col-12 col-md-9"><input type="file" id="text-input" name="gambar[]"placeholder="Choose file" class="form-control" value="">
                                            <?php
                                                if(isset($_GET['id_check'])){
                                                    $result1=mysqli_query($conn,"SELECT * FROM kategori WHERE id_kat = '$id_kat' ");
                                                    while ($row2=mysqli_fetch_array($result1)){
                                            ?>
                                            <div class="btn btn-outline-primary btn-sm">
                                                <?php echo $row2["foto_kat"];?>
                                            </div>
                                            <?php
                                                    }
                                                }
                                            ?>
                                            <small class="help-block form-text">Lampirkan Foto Alat untuk mempermudah proses pengecekan</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                    <i class="fa fa-dot-circle-o"></i> Submit
                                </button>
                            </div>
                        </form>
                    </div>    
                </div>
            </div>
            
        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>
