<?php 
    include "connection.php";
    include "header_admin.php";

    $cari;
    $act = "";
    $query="SELECT * FROM alat as a
        inner join checklist_record as cr
        on a.id_alat = cr.id_alat 
        inner join kategori as k
        on k.id_kat = a.id_kat 
;"; //query vendor


    if(isset($_GET["action"])){
        $act = $_GET["action"];
        if( $act == "valid"){
            $query="SELECT * FROM alat as a inner join checklist_record as cr on a.id_alat = cr.id_alat inner join kategori as k
                        on k.id_kat = a.id_kat where cr.kondisi = 'valid' order by cr.tgl_checklist desc;"; //query vendor
        } else if( $act== "rusak"){
            $query="SELECT * FROM alat as a inner join checklist_record as cr on a.id_alat = cr.id_alat inner join kategori as k
                        on k.id_kat = a.id_kat where cr.kondisi = 'rusak' order by cr.tgl_checklist desc;"; //query vendor
        }else if($act == "hilang"){
            $query="SELECT * FROM alat as a inner join checklist_record as cr on a.id_alat = cr.id_alat inner join kategori as k
                        on k.id_kat = a.id_kat where cr.kondisi = 'hilang' order by cr.tgl_checklist desc;"; //query vendor
        }else if($act == "diputihkan"){
            $query="SELECT * FROM alat as a inner join checklist_record as cr on a.id_alat = cr.id_alat inner join kategori as k
                        on k.id_kat = a.id_kat where cr.kondisi = 'diputihkan' order by cr.tgl_checklist desc;"; //query vendor
        }
    }
    if(isset($_GET["search"])){
        $cari=$_GET["text_search"];
        $query="SELECT * FROM alat WHERE `id_alat` LIKE '%$cari%' OR `merk` LIKE '%$cari%' OR 'type' LIKE '%$cari%';";
    }
    
    $result=mysqli_query($conn,$query);

?>
<html>

        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                        <div class="page-header float-left">
                            <div class="page-title">
                                <h1>Kondisi Alat <?php echo $act; ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="page-header float-right">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li class="active">Data CheckList Alat</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Data Tabel</strong>
                                <!-- <a href="form_alat.php" class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">Form Alat</a> -->
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>No. INV</th>
                                            <th>Nama Alat</th>
                                            <th>Kategori</th>
                                            <th>Tanggal Checklist</th>
                                            <th>Keterangan</th>
                                            <th>Kondisi</th>
                                            <th>Petugas</th>
                                            <th>ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i = 0;
                                        // $query1 = mysqli_query($conn, "SELECT * from alat as a inner join  checklist_record as cr on a.id_alat = cr.id_alat");
                                        while ($row1=mysqli_fetch_array($result)){
                                            $i++;
                                    ?>
                                        <tr>
                                            <td><?php echo $i ?></td>
                                            <td><?php echo $row1["id_alat"]; ?></td>
                                            <td><?php echo $row1["merk"]." ".$row1["type"]; ?></td>
                                            <td><?php echo $row1["name_kat"]; ?></td>
                                            <td><?php echo $row1["tgl_checklist"]; ?></td>
                                            <td><?php echo $row1["keterangan"]; ?></td>
                                            <td><?php echo $row1["kondisi"]; ?></td>
                                            <td><?php echo $row1["username"]; ?></td>
                                            <td> 
                                                <!-- <div class="btn btn-outline-primary btn-sm"><a  href="tampil_barang_masuk.php?id_alat=<?php echo $row1["id_alat"];?>"> <i class="fas fa-book-open fa-2x"></i> </a></div> -->
                                                <div class="btn btn-outline-primary btn-sm"><a  href="form_checklist.php?id_check=<?php echo $row1["id_check"];?>"> <i class='fa fa-pencil fa-2x'> </i> </a></div>
                                                <div class="btn btn-outline-danger btn-sm"><a  href="delete_checklist.php?id_check=<?php echo $row1["id_check"];?>"> <i class='fa fa-trash-o fa-2x'> </i> </a></div>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div><!-- .animated -->
        </div><!-- .content -->

        <div class="clearfix"></div>

<?php include 'footer_admin.php'; ?>
