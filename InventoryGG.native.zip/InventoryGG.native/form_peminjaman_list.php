<?php 
    $id_peminjaman_masuk = $id_detail_masuk = $id_kat = $jum_kat = $jumlah = $jumlah2 = $status = "";
    include "connection.php";

    if(isset($_GET['id_peminjaman_masuk'])){
        $id_peminjaman_masuk    =   $_GET['id_peminjaman_masuk'];
        $resultChecklist=mysqli_query($conn,"SELECT status FROM peminjaman_masuk where id_peminjaman_masuk = '$id_peminjaman_masuk'") ;
        while ($row6=mysqli_fetch_array($resultChecklist)){
            $status = $row6["status"];
        }
    }

    $query1="SELECT D.*, K.name_kat, K.foto_kat  FROM detail_peminjaman_masuk D,kategori K WHERE K.id_kat = D.id_kat AND id_peminjaman_masuk = '$id_peminjaman_masuk' ORDER BY D.`id_detail_masuk`";
    $result1=mysqli_query($conn,$query1) ;
    
    if(isset($_GET['edit']) and isset($_GET['id_peminjaman_masuk']) and isset($_GET['id_detail_masuk'])){
        $edit                   =   $_GET['edit'];
        $id_peminjaman_masuk    =   $_GET['id_peminjaman_masuk'];
        $id_detail_masuk        =   $_GET['id_detail_masuk'];
        $queryAlatEdit = "SELECT * FROM detail_peminjaman_masuk WHERE `id_detail_masuk` = '$id_detail_masuk';";
        $resultAlatEdit=mysqli_query($conn,$queryAlatEdit) ;
        while ($row1=mysqli_fetch_array($resultAlatEdit)){
            $id_kat     =   $row1["id_kat"];
            $jumlah     =   $row1["jumlah"];
        }
    }

    if(isset($_GET["id_peminjaman_masuk"]) and isset($_GET["id_kat"]) and isset($_GET["jumlah"]) and isset($_GET["id_detail_masuk"])and isset($_GET["status"])){
        $id_detail_masuk        =   $_GET['id_detail_masuk'];
        $id_peminjaman_masuk    =   $_GET["id_peminjaman_masuk"];
        $id_kat                 =   $_GET["id_kat"];
        $jumlah                 =   $_GET["jumlah"];
        $status                 =   $_GET["status"];
    }

    if(isset($_POST["reset1"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $id_detail_masuk        =   $_POST['id_detail_masuk'];
        $id_kat                 =   $_POST["id_kat"];
        $jumlah                 =   $_POST["jumlah"];
        $jumlah2                =   $_POST["jumlah2"];
        $status                =   $_POST["status"];
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk');
                } else {
                    location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk');
                }
            </script>";
        
    }

    if(isset($_POST["submit1"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $id_kat                 =   $_POST["id_kat"];
        $jumlah                 =   $_POST["jumlah"];
        $jumlah2                =   $_POST["jumlah2"];
        $id_detail_masuk        =   $_POST["id_detail_masuk"];
        $status = $_POST["status"];

        // $queryJum = "SELECT COUNT(a.`id_alat`) AS jumlahKat FROM alat a, kategori k WHERE a.`id_kat` = k.`id_kat` AND k.`id_kat`= '$id_kat' ;";
        // $resultJum=mysqli_query($conn,$queryJum) or die (mysqli_error());
        // while ($row1=mysqli_fetch_array($resultJum)){
        //     $jum_kat     =   $row1["jumlahKat"];
        // }

        // SELECT COUNT(a.`id_alat`) AS jumlahKat FROM `detail_peminjaman_diterima` d, `detail_peminjaman_masuk` p, `peminjaman_masuk` m, `alat` a , kategori k WHERE a.`id_kat` = k.`id_kat` AND m.`id_peminjaman_masuk` = p.`id_peminjaman_masuk` AND p.`id_detail_masuk` = d.`id_detail_masuk` AND d.`id_alat` = a.`id_alat` AND k.`id_kat`= '1' AND m.`tgl_ambil` = '';

        if($id_detail_masuk != ""){
            if(($id_detail_masuk and $id_peminjaman_masuk and $id_kat and $jumlah) != ""){
                $sql_insert1 = false;
                $query1="UPDATE detail_peminjaman_masuk SET id_kat='$id_kat', jumlah='$jumlah', jumlah_dikeluarkan='$jumlah2' WHERE id_detail_masuk = '$id_detail_masuk';";
                $sql_insert1 = mysqli_query($conn,$query1);
            }else{
                echo "<script>alert('Ada data yang kosong')
                location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }else{
            if(($id_peminjaman_masuk and $id_kat and $jumlah and $jumlah2) != ""){
                $sql_insert1 = false;
                $query1="INSERT INTO detail_peminjaman_masuk set id_peminjaman_masuk = '$id_peminjaman_masuk', id_kat = '$id_kat', jumlah = '$jumlah', jumlah_dikeluarkan = '$jumlah2' ;";
                $sql_insert1 = mysqli_query($conn,$query1);
            }else if(($id_peminjaman_masuk and $id_kat and $jumlah) != ""){
                $sql_insert1 = false;
                $query1="INSERT INTO detail_peminjaman_masuk set id_peminjaman_masuk = '$id_peminjaman_masuk', id_kat = '$id_kat', jumlah = '$jumlah' ;";
                $sql_insert1 = mysqli_query($conn,$query1);
            }else{
                echo "<script>alert('Ada data yang kosong')
                location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
            }
        }

        if($sql_insert1){
            echo "<script>alert('Data Berhasil Ditambahkan')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }else{
            echo "<script>alert('Data gagal Ditambahkan')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk')</script>";
        }
                
            
    }
?>

<?php
        include 'header_admin.php';
    ?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form List Alat Peminjaman</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Data Peminjaman</a></li>
                                <li><a href="form_peminjaman.php?edit=true&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>">Form Peminjaman</a></li>
                                <li class="active">Form List Alat</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Pilih item yang akan dipinjam <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <form action="form_peminjaman_list.php" method="post" name="frm" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="row form-group">
                                    <div class="col col-md-3">
                                        <label for="text-input" class=" form-control-label">Jenis Alat</label>
                                    </div>
                                    <div class="col-12 col-md-9">
                                        <select name="id_kat" class="form-control">
                                            <?php
                                                if($id_kat == ""){
                                                    echo "<option selected>-- Pilih Jenis Alat --</option>";
                                                }
                                                $query="SELECT * FROM kategori";
                                                $sql=mysqli_query($conn,$query);
                                                while ($row=mysqli_fetch_array($sql)) {
                                                    $select = $valueAlat = $tampilAlat ="";
                                                    $valueAlat =  $row['id_kat'];
                                                    $tampilAlat = $row['name_kat'];
                                                    if ($row['id_kat']==$id_kat) {
                                                        $select="selected";
                                                    }
                                            ?>
                                            <option <?php echo $select; ?> value="<?php echo $valueAlat;?>">
                                                <?php echo $tampilAlat; ?> 
                                                <?php if($row["foto_kat"] != "" || !empty($row["foto_kat"] || $row["foto_kat"] != null)){ ?>
                                                <div class="text-center">
                                                    <img src="images/<?php echo $row["foto_kat"];?>" width="120px" height="120px" 
                                                        class="img-responsive rounded" alt="">
                                                </div>
                                            <?php } ?>
                                            </option>
                                            <?php
                                                }
                                            ?>
                                        </select>
                                        <small class="form-text text-muted">pilih jenis alat</small>
                                    </div>
                                </div>
                                <div class="row form-group">
                                    <div class="col col-md-3">
                                        <label for="text-input" class=" form-control-label">Masukkan jumlah</label>
                                    </div>
                                    <div class="col-12 col-md-9">
                                        <input type="number" id="email-input" name="jumlah" placeholder="Masukkan jumlah alat" 
                                        class="form-control" value="<?php echo $jumlah; ?>">
                                        <small class="help-block form-text">Masukkan jumlah yang akan dipinjam</small>
                                    </div>
                                    <input type="text" id="email-input" name="id_peminjaman_masuk" hidden="hidden"
                                        class="form-control" value="<?php echo $id_peminjaman_masuk; ?>">
                                    <input type="text" id="email-input" name="status" hidden="hidden" class="form-control"
                                        value="<?php echo $status; ?>">
                                    <input type="text" id="email-input" name="id_detail_masuk" hidden="hidden"
                                        class="form-control" value="<?php echo $id_detail_masuk; ?>">
                                </div>
                                <?php 
                                        $hidJum = "hidden";
                                        if($status != 'baru'){
                                            $hidJum = "";
                                        } 
                                    ?>
                                <div class="row form-group" <?php echo $hidJum; ?>>
                                    <div class="col col-md-3">
                                        <label for="text-input" class=" form-control-label">Masukkan jumlah yang disetujui</label>
                                    </div>
                                    <div class="col-12 col-md-9">
                                        <input type="number" id="email-input" name="jumlah2" placeholder="Masukkan jumlah alat yang disetujui" 
                                            class="form-control" value="<?php echo $jumlah2; ?>">
                                        <small class="help-block form-text">Masukkan jumlah yang akan disetujui</small>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit1">
                                    <i class="fa fa-dot-circle-o"></i> Submit
                                </button>
                                <button type="submit" class="btn btn-danger btn-sm" name="reset1">
                                    <i class="fa fa-ban"></i> Reset
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Permintaan Peminjaman Baru <?php echo $id_peminjaman_masuk; ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Foto Alat</th>
                                        <th>Jenis Alat</th>
                                        <th>Jumlah</th>
                                        <th>Jumlah Disetujui</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                        while ($row2=mysqli_fetch_array($result1)){
                                            $i++;
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td>
                                            <?php if($row2["foto_kat"] != "" || !empty($row2["foto_kat"] || $row2["foto_kat"] != null)){ ?>
                                                <div class="text-center">
                                                    <img src="images/<?php echo $row2["foto_kat"];?>" width="120px" height="120px" 
                                                        class="img-responsive rounded" alt="">
                                                </div>
                                            <?php } ?>
                                        </td>
                                        <td><?php echo $row2["name_kat"]; ?></td>
                                        <td><?php echo $row2["jumlah"]; ?></td>
                                        <td><?php echo $row2["jumlah_dikeluarkan"]; ?></td>
                                        <td>
                                            <div class="btn btn-outline-primary btn-sm"><a
                                                    href="form_peminjaman_list.php?edit=true&id_peminjaman_masuk=<?php echo $row2["id_peminjaman_masuk"];?>&id_detail_masuk=<?php echo $row2["id_detail_masuk"];?>">
                                                    <i class='fa fa-pencil fa-2x'> </i> </a></div>
                                            <div class="btn btn-outline-danger btn-sm"><a
                                                    href="delete_detail_peminjaman.php?id_detail_masuk=<?php echo $row2["id_detail_masuk"];?>&id_masuk=<?php echo $row2["id_peminjaman_masuk"];?>&user=admin">
                                                    <i class='fa fa-trash-o fa-2x'> </i> </a></div>

                                        </td>
                                    </tr>
                                    <?php
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- BUTTON BACK -->
            <div class="float-left">
                <a href="form_peminjaman.php?edit=true&id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>" class="btn btn-secondary btn-md active float-left" role="button" aria-pressed="true">
                    < Back
                </a> 
            </div> 

            <!-- BUTTON NEXT -->
            <?php
                $jum_kat = "";
                $queryKat="SELECT COUNT(*) as jumkat  FROM detail_peminjaman_masuk D,kategori K WHERE K.id_kat = D.id_kat AND id_peminjaman_masuk = '$id_peminjaman_masuk' ORDER BY D.`id_detail_masuk`;";
                $resultKat=mysqli_query($conn,$queryKat) ;
                while ($row2=mysqli_fetch_array($resultKat)){
                    $jum_kat = $row2["jumkat"];
                }
                $href = "";
                if($jum_kat != "" && $jum_kat != "0"){
                    $href = "form_peminjaman_list_alat.php?id_peminjaman_masuk=". $id_peminjaman_masuk;
                }else{
                    $href = "tampil_peminjaman.php?id_peminjaman_masuk=" . $id_peminjaman_masuk;
                }
            ?>
            <div class="float-right">
                <a href="<?php echo $href; ?>" class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">
                    Next >
                </a>
            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>