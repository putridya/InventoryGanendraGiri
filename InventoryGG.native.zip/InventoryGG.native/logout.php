<?php 
// mengaktifkan session
session_start();
include 'connection.php';

$username = $_SESSION['username'];
$query2 = "UPDATE user set login_status = 'logout' WHERE username = '$username'";
$result2=mysqli_query($conn,$query2);
if($result2){
    // menghapus semua session
    session_destroy();

    // mengalihkan halaman sambil mengirim pesan logout
    header("location:login.php?pesan=logout");
}else{
    echo "<script>alert('Berhasil Menambahkan Data Checklist peminjaman')
         location.replace('insert_detail_peminjaman_diterima.php?id_check=$id_check_max&id_peminjaman_masuk=$id_peminjaman_masuk&id_detail_masuk=$id_detail_masuk&status_peminjaman=$status_peminjaman&id_alat=$id_alat')</script>";
                    
}
 

?>