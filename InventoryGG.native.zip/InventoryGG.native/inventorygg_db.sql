/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.4.6-MariaDB : Database - inventorygg
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`inventorygg` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `inventorygg`;

/*Table structure for table `alat` */

DROP TABLE IF EXISTS `alat`;

CREATE TABLE `alat` (
  `id_alat` varchar(25) NOT NULL,
  `merk` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `id_kat` int(11) DEFAULT NULL,
  `tgl_masuk` date DEFAULT NULL,
  `tgl_keluar` date DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_alat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `alat` */

insert  into `alat`(`id_alat`,`merk`,`type`,`id_kat`,`tgl_masuk`,`tgl_keluar`,`id_user`) values ('1/INV-ALT/OPA-GG/037','Pe','ATC',1,'0000-00-00','0000-00-00',0),('11/INV-ALT/OPA-GG/037','petzl ','Ascenssion',11,'2019-11-20','0000-00-00',0),('12/INV-ALT/OPA-GG/038','petzl ','Croll',12,'2019-11-20','0000-00-00',0),('20/INV-ALT/OPA-GG/035','black diamond','momentum',20,'2019-11-11','0000-00-00',0),('21/INV-ALT/OPA-GG/035','black diamond','momentum',21,'2019-11-09','0000-00-00',0),('21/INV-ALT/OPA-GG/036','petzl ','Luna',21,'2019-11-20','0000-00-00',0),('9/INV-ALT/OPA-GG/037','Petzl ','Hunt',9,'2019-11-20','0000-00-00',0);

/*Table structure for table `checklist_group` */

DROP TABLE IF EXISTS `checklist_group`;

CREATE TABLE `checklist_group` (
  `id_checklist_group` varchar(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_alat` int(11) DEFAULT NULL,
  `tgl_check` date DEFAULT NULL,
  PRIMARY KEY (`id_checklist_group`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `checklist_group` */

/*Table structure for table `checklist_record` */

DROP TABLE IF EXISTS `checklist_record`;

CREATE TABLE `checklist_record` (
  `id_check` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_checklist` date DEFAULT NULL,
  `id_alat` varchar(25) DEFAULT NULL,
  `kondisi` varchar(50) DEFAULT NULL,
  `keterangan` tinytext DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `dipinjam` varchar(11) DEFAULT NULL,
  `id_detail` int(11) DEFAULT NULL,
  `id_checklist_group` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id_check`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `checklist_record` */

/*Table structure for table `detail_peminjaman_diterima` */

DROP TABLE IF EXISTS `detail_peminjaman_diterima`;

CREATE TABLE `detail_peminjaman_diterima` (
  `id_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_detail_masuk` int(11) DEFAULT NULL,
  `id_alat` varchar(25) DEFAULT NULL,
  `id_check_keluar` int(11) DEFAULT NULL,
  `id_check_masuk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `detail_peminjaman_diterima` */

insert  into `detail_peminjaman_diterima`(`id_detail`,`id_detail_masuk`,`id_alat`,`id_check_keluar`,`id_check_masuk`) values (1,NULL,NULL,NULL,NULL);

/*Table structure for table `detail_peminjaman_masuk` */

DROP TABLE IF EXISTS `detail_peminjaman_masuk`;

CREATE TABLE `detail_peminjaman_masuk` (
  `id_detail_masuk` int(11) NOT NULL AUTO_INCREMENT,
  `id_peminjaman_masuk` varchar(25) DEFAULT NULL,
  `id_kat` int(11) DEFAULT NULL,
  `jumlah` int(5) DEFAULT NULL,
  `jumlah_dikeluarkan` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_detail_masuk`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `detail_peminjaman_masuk` */

insert  into `detail_peminjaman_masuk`(`id_detail_masuk`,`id_peminjaman_masuk`,`id_kat`,`jumlah`,`jumlah_dikeluarkan`) values (1,'PJ20191007001',2,3,NULL),(2,'PJ20191007001',1,7,NULL),(3,'PJ20191007001',2,5,NULL),(4,'PJ20191007001',2,5,NULL),(5,'PJ20191007001',2,5,NULL),(6,'PJ20191008004',7,6,NULL),(7,'PJ20191007001',7,5,NULL),(8,'PJ20191007001',1,5,NULL),(9,'PJ20191008004',4,4,NULL),(10,'PJ20191028002',4,5,0),(11,'PJ20191028801',1,3,0),(12,'PJ20191028801',1,3,2);

/*Table structure for table `foto_surat` */

DROP TABLE IF EXISTS `foto_surat`;

CREATE TABLE `foto_surat` (
  `id_surat` int(11) NOT NULL AUTO_INCREMENT,
  `id_peminjaman_masuk` varchar(25) DEFAULT NULL,
  `nama_file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `foto_surat` */

insert  into `foto_surat`(`id_surat`,`id_peminjaman_masuk`,`nama_file`) values (1,'PJ20191008002','WhatsApp Image 2019-09-26 at 15.03.29.jpeg'),(2,'PJ20191008002','WhatsApp Image 2019-10-01 at 13.02.31.jpeg'),(6,'PJ20191028002','WhatsApp Image 2019-09-26 at 15.03.29.jpeg'),(7,'PJ20191028801',''),(8,'PJ20191125802','');

/*Table structure for table `kategori` */

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `id_kat` int(11) NOT NULL AUTO_INCREMENT,
  `name_kat` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_kat`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

/*Data for the table `kategori` */

insert  into `kategori`(`id_kat`,`name_kat`) values (4,'Carrabiner Screw Delta'),(5,'Carrabiner Snap Delta'),(6,'Carrabiner Screw Oval'),(7,'Carrabiner Screw A'),(8,'Carrabiner TriadLock delta'),(9,'Figure of eight (descender)'),(10,'AutoStop (descender)'),(11,'Hand Ascender'),(12,'Chest Ascender'),(13,'Mellion Rapid Delta'),(14,'Mellion Rapid Oval'),(15,'Piton'),(16,'Chock Stopper'),(17,'Choker'),(18,'Hammer'),(19,'Pully Mono'),(20,'Sit Harness gym climbing'),(21,'Sit Harness wall climbing');

/*Table structure for table `peminjaman_masuk` */

DROP TABLE IF EXISTS `peminjaman_masuk`;

CREATE TABLE `peminjaman_masuk` (
  `id_peminjaman_masuk` varchar(25) NOT NULL,
  `nama_instansi` varchar(50) DEFAULT NULL,
  `email_peminjam` varchar(50) DEFAULT NULL,
  `nama_kegiatan` varchar(50) DEFAULT NULL,
  `tgl_ambil` date DEFAULT NULL,
  `tgl_kembali` date DEFAULT NULL,
  `no_wa` varchar(13) DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_peminjaman_masuk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `peminjaman_masuk` */

insert  into `peminjaman_masuk`(`id_peminjaman_masuk`,`nama_instansi`,`email_peminjam`,`nama_kegiatan`,`tgl_ambil`,`tgl_kembali`,`no_wa`,`status`) values ('PJ20191007001','Ranti Pager Aji','RPA@gmail.com','latgab','2019-10-19','2019-10-20','08122456921','baru'),('PJ20191008002','jongring salaka','js@gmail.com','fun rafting','2019-10-18','2019-10-22','08125837291','baru'),('PJ20191008003','aspal','aspal@gmail.com','latihan SRT','2019-10-15','2019-10-18','08128438930','baru'),('PJ20191008004','aspal','aspal@gmail.com','latihan SRT','2019-10-26','2019-10-30','0812734912','dikembalikan'),('PJ20191019001','HWC','HWC@gmail.com','fun rafting','2019-10-21','2019-10-26','081243789102','baru'),('PJ20191028002','Vicnecvara','vicnecvara@gmail.com','diksar','2019-10-31','2019-11-07','085896404314','disetujui'),('PJ20191028801','Dimpa','dimpa@gmail.com','survey','2019-11-02','2019-11-03','0858028493101','diambil'),('PJ20191125802','jongring salaka','aspal@gmail.com','fun rafting','2019-11-28','2019-11-30','08589640414','baru');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(50) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `nia` varchar(11) DEFAULT NULL,
  `posisi` varchar(25) DEFAULT NULL,
  `login_status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id_user`,`nama_user`,`username`,`password`,`nia`,`posisi`,`login_status`) values (1,'kagura','kagura','kagura','910280519','admin',NULL),(2,'M.Yusril Iqbal','palapa','palapa','910280513','admin',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
