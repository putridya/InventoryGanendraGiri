<?php 
	include "connection.php";

    $id_peminjaman_masuk = $nama_instansi = $nama_kegiatan = $email_peminjam = $tgl_ambil = $tgl_kembali =  $no_wa = $status = $edit = $id_detailmasuk = $id_kat = $jumlah = $name_kat = $foto_surat = null;
    

    if(isset($_GET['edit']) and isset($_GET['id_peminjaman_masuk'])){
        $edit                   =   $_GET['edit'];
        $id_peminjaman_masuk    =   $_GET['id_peminjaman_masuk'];
        $result=mysqli_query($conn,"SELECT * FROM peminjaman_masuk WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
        while ($row1=mysqli_fetch_array($result)){
            $nama_instansi      =   $row1["nama_instansi"];
            $email_peminjam     =   $row1["email_peminjam"];
            $nama_kegiatan      =   $row1["nama_kegiatan"];
            $tgl_ambil          =   $row1["tgl_ambil"];
            $tgl_kembali        =   $row1["tgl_kembali"];
            $no_wa              =   $row1["no_wa"];
            $status             =   $row1["status"];
        }
    }

    if(isset($_GET['nama_instansi']) and isset($_GET['nama_kegiatan']) and isset($_GET['email_peminjam'])){
        $nama_instansi      =   $_GET['nama_instansi'];
        $email_peminjam     =   $_GET['email_peminjam'];
        $nama_kegiatan      =   $_GET['nama_kegiatan'];
        $tgl_ambil          =   $_GET["tgl_ambil"];
        $tgl_kembali        =   $_GET["tgl_kembali"];
        $no_wa              =   $_GET["no_wa"];
        $status             =   $_GET["status"];
    }

    if(isset($_POST["reset"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $nama_instansi          =   $_POST["nama_instansi"];
        $email_peminjam         =   $_POST["email_peminjam"];
        $nama_kegiatan          =   $_POST["nama_kegiatan"];
        $tgl_ambil              =   $_POST["tgl_ambil"];
        $tgl_kembali            =   $_POST["tgl_kembali"];
        $no_wa                  =   $_POST["no_wa"];
        $status                 =   $_POST["status"];

        if($id_peminjaman_masuk != null){
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('form_peminjaman.php');
                } else {
                    location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk');
                }
            </script>";
        }else{
            echo "
            <script>
                if (confirm('Do you want clean this form?')) {
                    location.replace('form_peminjaman.php');
                } else {
                    location.replace('form_peminjaman.php?nama_instansi=$nama_instansi&nama_kegiatan=$nama_kegiatan&email_peminjam=$email_peminjam');
                }
            </script>";
        }
        
    }

    if(isset($_POST["submit"])){
        $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
        $nama_instansi          =   $_POST["nama_instansi"];
        $email_peminjam         =    $_POST["email_peminjam"];
        $nama_kegiatan          =   $_POST["nama_kegiatan"];
        $tgl_ambil              =   $_POST["tgl_ambil"];
        $tgl_kembali            =   $_POST["tgl_kembali"];
        $no_wa                  =   $_POST["no_wa"];
        $status                 =   $_POST["status"];
        $edit                   =   $_POST['edit'];
        $sql_insert1;

        if($edit != true){
            if(($nama_instansi and $nama_kegiatan and $email_peminjam and $nama_kegiatan and $tgl_ambil and $tgl_kembali and $no_wa and $status) != null){
                $query="INSERT INTO peminjaman_masuk (id_peminjaman_masuk, nama_instansi,nama_kegiatan,email_peminjam,tgl_ambil,tgl_kembali,no_wa,status) VALUES ('".$id_peminjaman_masuk."','".$nama_instansi."','".$nama_kegiatan."','".$email_peminjam."','".$tgl_ambil."','".$tgl_kembali."','".$no_wa."','".$status."');";
                $sql_insert1 = mysqli_query($conn,$query);

                $jumlah = count($_FILES['gambar']['name']);
                if ($jumlah > 0) {
                    for ($i=0; $i < $jumlah; $i++) { 
                        $file_name = $_FILES['gambar']['name'][$i];
                        $tmp_name = $_FILES['gambar']['tmp_name'][$i];				
                        move_uploaded_file($tmp_name, "images/".$file_name);
                        $sql_insert2 = mysqli_query($conn,"INSERT INTO foto_surat VALUES('','$id_peminjaman_masuk','$file_name')");				
                    }
                }
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }else{
            if(($nama_instansi and $nama_kegiatan and $email_peminjam) != null){
                $query="UPDATE peminjaman_masuk set nama_instansi = '$nama_instansi', nama_kegiatan = '$nama_kegiatan', email_peminjam = '$email_peminjam', tgl_ambil = '$tgl_ambil', tgl_kembali = '$tgl_kembali', no_wa = '$no_wa', status = '$status' where id_peminjaman_masuk = '$id_peminjaman_masuk';";
                $sql_insert1 = mysqli_query($conn,$query);
            }else{
                echo "<script>alert('Ada data yang kosong')</script>";
            }
        }

        if($sql_insert1){
            echo "<script>alert('Data Berhasil Ditambahkan')
            location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }else{
            echo "<script>alert('Data Gagal Ditambahkan')
            location.replace('form_peminjaman.php?edit=true&id_peminjaman_masuk=$id_peminjaman_masuk')</script>";
        }
    }

    if(isset($_POST["reset"])){
       $nama_instansi = $nama_kegiatan = $email_peminjam = $tgl_ambil = $tgl_kembali = $no_wa = $status=  $edit = null;
    }

    if(isset($_POST["reset1"])){
        $id_peminjaman_masuk = $id_detailmasuk = $id_kat = $jumlah = $name_kat = $query = null;
    }

    if($id_peminjaman_masuk == ""){
        date_default_timezone_set("Asia/Jakarta");
        $date= date("Ymd");
        $query =mysqli_query($conn, "SELECT max(id_peminjaman_masuk) as maxKode FROM peminjaman_masuk");
        $data = mysqli_fetch_array($query);
        $noOrder = $data['maxKode'];
        $noUrut = (int) substr($noOrder, 10, 3);
        $noUrut++;
        $char = "PJ";
        $tahun=substr($date, 0, 4);
        $bulan=substr($date, 5, 2);
        $id_peminjaman_masuk = $char .$date . sprintf("%03s", $noUrut);
    }
    
    // HEADER INCLUDE
    include 'header_admin.php';
 ?>

<body>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Form Peminjaman</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard_admin.php">Data Peminjaman</a></li>
                                <li class="active">Form Peminjaman</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Isikan Data Peminjaman <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <form action="form_peminjaman.php" method="post" name="frm" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body card-block">
                                <div class="container">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Nama Instansi</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="nama_instansi"placeholder="Nama Instansi" 
                                                class="form-control" value="<?php echo $nama_instansi; ?>">
                                            <small class="form-text text-muted">Masukkan Nama Instansi</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="email-input" class=" form-control-label">Email Peminjam</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="email_peminjam" placeholder="Email Peminjam" 
                                                class="form-control" value="<?php echo $email_peminjam; ?>">
                                            <small class="form-text text-muted">Masukkan Email Peminjam</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Nama Kegiatan</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="text-input" name="nama_kegiatan" placeholder="Nama Kegiatan" 
                                                class="form-control" value="<?php echo  $nama_kegiatan; ?>">
                                            <small class="help-block form-text">Masukkan Nama Kegiatan</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Tanggal Ambil</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="date" id="email-input" name="tgl_ambil" placeholder="Tanggal Ambil" 
                                                class="form-control" value="<?php echo $tgl_ambil; ?>">
                                            <small class="help-block form-text">Masukkan Tanggal Ambil</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Tanggal Kembali</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="date" id="email-input" name="tgl_kembali" placeholder="Tanggal Kembali" 
                                            class="form-control" value="<?php echo $tgl_kembali; ?>">
                                            <small class="help-block form-text">Masukkan Tanggal Kembali</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Nomor WhatsApp Peminjam</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="number" id="email-input" name="no_wa" placeholder="Nomor WhatsApp Peminjam" 
                                                class="form-control" value="<?php echo $no_wa; ?>">
                                            <small class="help-block form-text">Masukkan Nomor WhatsApp Peminjam</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Status</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <select name="status" class="form-control">
                                                <?php if($status == "") {echo "<option selected>-- Pilih Status --</option>";}?>
                                                <option <?php if($status == "baru") {echo "selected";} ?> value="baru">Baru
                                                </option>
                                                <option <?php if($status == "disetujui") {echo "selected";} ?>
                                                    value="disetujui">Disetujui</option>
                                                <option <?php if($status == "diambil") {echo "selected";} ?>
                                                    value="diambil">Diambil</option>
                                                <option <?php if($status == "dikembalikan") {echo "selected";} ?>
                                                    value="dikembalikan">Dikembalikan</option>
                                            </select>
                                            <small class="help-block form-text">Masukkan Status</small>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="text-input" class=" form-control-label">Lampirkan foto surat</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input type="file" id="text-input" name="gambar[]" placeholder="Choose file" 
                                                class="form-control" value="" multiple>
                                            <?php
                                                    if(isset($_GET['id_peminjaman_masuk'])){
                                                        $result1=mysqli_query($conn,"SELECT * FROM foto_surat WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
                                                        while ($row2=mysqli_fetch_array($result1)){
                                                ?>
                                            <div class="btn btn-outline-primary btn-sm"><?php echo $row2["nama_file"];?><a
                                                    href="delete_foto.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>&id_surat=<?php echo $row2["id_surat"];?>">
                                                    <i class='fas fa-times-circle'> </i> </a></div>
                                            <?php
                                                        }
                                                    }
                                                ?>
                                            <small class="help-block form-text">Lampirkan Foto surat (jika ada) untuk mempermudah proses peminjaman</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <!-- HIDDEN INPUT -->
                                <input type="text" id="email-input" name="id_peminjaman_masuk" class="form-control"
                                            value="<?php echo $id_peminjaman_masuk; ?>" hidden="hidden">
                                <input type="text" id="email-input" name="edit" class="form-control"
                                            value="<?php echo $edit; ?>" hidden="hidden">
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                    <i class="fa fa-dot-circle-o"></i> Submit
                                </button>
                                <button type="submit" class="btn btn-danger btn-sm" name="reset">
                                    <i class="fa fa-ban"></i> Reset
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


            <?php 
                if(isset($_GET['id_peminjaman_masuk'])){
                    $jumlah_foto = 0;
                    $result=mysqli_query($conn,"SELECT COUNT(*) AS jum FROM foto_surat F, peminjaman_masuk P WHERE p.`id_peminjaman_masuk` = f.`id_peminjaman_masuk` AND f.`id_peminjaman_masuk` = '$id_peminjaman_masuk';");
                    while ($row1=mysqli_fetch_array($result)){
                        $jumlah_foto      =   $row1["jum"];
                    }
                    $hidden_foto = "hidden";
                    if($jumlah_foto != 0 ){ $hidden_foto = "";}

            ?>
            <div class="row" <?php echo $hidden_foto; ?>>
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Lampiran Foto Surat <?php echo $id_peminjaman_masuk ?></strong>
                        </div>
                        <div class="card-body card-block">
                            <div class="container">
                                <div class="row" >
                                    <div class="col-lg-12">
                                        <div class="card">
                                            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                                                <ol class="carousel-indicators">
                                                    <?php
                                                        for($i = 0; $i > $jumlah_foto; $i++){
                                                    ?>
                                                    <li data-target="#carouselExampleCaptions" data-slide-to="<?php echo $i; ?>" 
                                                        class="<?php if($jumlah_foto == 0){ echo 'active';} ?>"></li>
                                                    <?php } ?>
                                                </ol>
                                                <div class="carousel-inner">
                                                    <?php
                                                        $i = 0;
                                                        $result1=mysqli_query($conn,"SELECT * FROM foto_surat WHERE id_peminjaman_masuk = '$id_peminjaman_masuk' ");
                                                        while ($row2=mysqli_fetch_array($result1)){
                                                    ?>
                                                    <div class="carousel-item <?php if($i == 0){ echo 'active';} ?>">
                                                        <img src="images/<?php echo $row2["nama_file"];?>" class="d-block w-100" alt="">
                                                        <div class="carousel-caption d-none d-md-block">
                                                            <p>File name : <?php echo $row2["nama_file"];?></p>
                                                        </div>
                                                    </div>
                                                    <?php
                                                        $i++;    
                                                        }
                                                    ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button"
                                                    data-slide="prev">
                                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Previous</span>
                                                </a>
                                                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button"
                                                    data-slide="next">
                                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>


            <!-- BUTTON BACK -->
            <div class="float-left">
                <a href="dashboard_admin.php?action=baru.php" class="btn btn-secondary btn-md active float-left" 
                    role="button" aria-pressed="true">
                    < Back
                </a> 
            </div> 

            <!-- BUTTON NEXT -->
            <?php if(isset($_GET['id_peminjaman_masuk'])){ ?>
            <div class="float-right">
                <a href="form_peminjaman_list.php?id_peminjaman_masuk=<?php echo $id_peminjaman_masuk;?>"
                    class="btn btn-primary btn-md active float-right" role="button" aria-pressed="true">
                    Next >
                </a>
            </div>
            <?php } ?>

        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>
<?php include 'footer_admin.php'; ?>