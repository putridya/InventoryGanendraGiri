<?php
    $id_peminjaman_masuk    =   $_POST["id_peminjaman_masuk"];
    $id_kat                 =   $_POST["id_kat"];
    $jumlah                 =   $_POST["jumlah"];
    $jumlah2                =   $_POST["jumlah2"];
    $id_detail_masuk        =   $_POST["id_detail_masuk"];
    $status = $_POST["status"];

    // $queryJum = "SELECT COUNT(a.`id_alat`) AS jumlahKat FROM alat a, kategori k WHERE a.`id_kat` = k.`id_kat` AND k.`id_kat`= '$id_kat' ;";
    // $resultJum=mysqli_query($conn,$queryJum) or die (mysqli_error());
    // while ($row1=mysqli_fetch_array($resultJum)){
    //     $jum_kat     =   $row1["jumlahKat"];
    // }

    // SELECT COUNT(a.`id_alat`) AS jumlahKat FROM `detail_peminjaman_diterima` d, `detail_peminjaman_masuk` p, `peminjaman_masuk` m, `alat` a , kategori k WHERE a.`id_kat` = k.`id_kat` AND m.`id_peminjaman_masuk` = p.`id_peminjaman_masuk` AND p.`id_detail_masuk` = d.`id_detail_masuk` AND d.`id_alat` = a.`id_alat` AND k.`id_kat`= '1' AND m.`tgl_ambil` = '';

    if($id_detail_masuk != ""){
        if(($id_detail_masuk and $id_peminjaman_masuk and $id_kat and $jumlah) != ""){
            $sql_insert1 = false;
            $query1="UPDATE detail_peminjaman_masuk SET id_kat='$id_kat', jumlah='$jumlah', jumlah_dikeluarkan='$jumlah2' WHERE id_detail_masuk = '$id_detail_masuk';";
            $sql_insert1 = mysqli_query($conn,$query1);
        }else{
            echo "<script>alert('Ada data yang kosong')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&status=$status')</script>";
        }
    }else{
        if(($id_peminjaman_masuk and $id_kat and $jumlah and $jumlah2) != ""){
            $sql_insert1 = false;
            $query1="INSERT INTO detail_peminjaman_masuk set id_peminjaman_masuk = '$id_peminjaman_masuk', id_kat = '$id_kat', jumlah = '$jumlah', jumlah_dikeluarkan = '$jumlah2' ;";
            $sql_insert1 = mysqli_query($conn,$query1);
        }else if(($id_peminjaman_masuk and $id_kat and $jumlah) != ""){
            $sql_insert1 = false;
            $query1="INSERT INTO detail_peminjaman_masuk set id_peminjaman_masuk = '$id_peminjaman_masuk', id_kat = '$id_kat', jumlah = '$jumlah' ;";
            $sql_insert1 = mysqli_query($conn,$query1);
        }else{
            echo "<script>alert('Ada data yang kosong')
            location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&status=$status')</script>";
        }
    }

    if($sql_insert1){
        echo "<script>alert('Data Berhasil Ditambahkan')
        location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&status=$status')</script>";
    }else{
        echo "<script>alert('Data gagal Ditambahkan')
        location.replace('form_peminjaman_list.php?id_peminjaman_masuk=$id_peminjaman_masuk&id_kat=$id_kat&jumlah=$jumlah&id_detail_masuk=$id_detail_masuk&status=$status')</script>";
    }
?>